"""Stage-two material fitting on the exact frozen GGGS geometry/footprints."""
import json
import random
import time
from pathlib import Path
import numpy as np
import torch
from data import SceneDataset,split_train_lights
from evaluate import (to_device,target_image,observation_image,ssim,save_pair,
    neutral_peak_metrics,aggregate_neutral_peak_metrics,neutral_peak_components,
    aggregate_neutral_peak_components)
from local_fragments import FrozenGeometry,gather,composite,quadrature,extension
from methods.local_transport import LocalMaterial
from renderer import visibility_hint
from gggs_reconstruction import author_modules

def render_pixels(geometry,material,sample,projection,visibility,pixels,config):
    fragments=gather(projection,pixels)
    pieces=[];n=len(fragments['gid'])
    for start in range(0,n,config['local_shader_chunk']):
        end=start+config['local_shader_chunk']
        subset=dict(fragments,gid=fragments['gid'][start:end],qid=fragments['qid'][start:end])
        positions,u,rotation,masses=quadrature(geometry,sample,projection,subset,config['local_quadrature'])
        pieces.append(material(geometry,subset['gid'],positions,u,rotation,masses,sample,visibility))
    colors=torch.cat(pieces) if pieces else material.features[:0,:3]
    linear,alpha=composite(colors,fragments,config['background'])
    predicted=observation_image(linear,config['display_gamma'],alpha=alpha,background=config['background'])
    return predicted,alpha,n

def patch_pixels(sample,patch,count):
    h,w=sample['image'].shape[:2];side=patch+10
    y=torch.randint(h-side+1,(count,),device='cuda');x=torch.randint(w-side+1,(count,),device='cuda')
    # Explicit foreground-emphasized patch objective: half foreground centers,
    # half uniform rectangles; no claim of an unbiased whole-image estimator.
    foreground=torch.nonzero(sample['alpha'][...,0]>.9)
    n=count//2
    if n:
        centers=foreground[torch.randint(len(foreground),(n,),device='cuda')]
        y[:n]=(centers[:,0]-side//2).clamp(0,h-side)
        x[:n]=(centers[:,1]-side//2).clamp(0,w-side)
    yy,xx=torch.meshgrid(torch.arange(side,device='cuda'),torch.arange(side,device='cuda'),indexing='ij')
    return ((y[:,None,None]+yy)*w+x[:,None,None]+xx).flatten(),side

def train_local(args):
    torch.set_num_threads(8);torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
    torch.backends.cuda.matmul.allow_tf32=True
    extension();author_modules()
    source=torch.load(args.init_geometry,map_location='cuda',weights_only=False)
    if source['kind']!='gggs_core':raise ValueError('Local material stage requires the selected GGGS geometry')
    data=SceneDataset(args.scene,'train',args.resolution)
    fit,val=(list(range(len(data))),[]) if args.fit_all else split_train_lights(data.frames)
    if source['config']['scene']!=str(data.scene_path.resolve()) or source['config']['resolution']!=args.resolution:
        raise ValueError('Source geometry scene/resolution differs')
    if not set(source['fit_indices']).issubset(fit) or (not args.fit_all and source['val_indices']!=val):
        raise ValueError('Source geometry has seen held-out material frames')
    geometry=FrozenGeometry.from_gggs(source)
    config=dict(vars(args),representation='local_transport',geometry='3dgs',geometry_frozen=True,
        source_geometry=str(Path(args.init_geometry).resolve()),source_geometry_step=source['step'],
        source_geometry_fit_indices=source['fit_indices'],source_geometry_val_indices=source['val_indices'],
        protocol='Frozen GGGS EWA footprints; per-contribution conditional-Gaussian quadrature; local positive total response',
        geometry_source_config=source['config'])
    del source
    out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    (out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
    (out/'split.json').write_text(json.dumps(dict(fit=fit,validation=val),indent=2)+'\n')
    samples={i:to_device(data[i],'cuda') for i in fit}
    irradiance=torch.stack([s['light_intensity']/(s['light_pos']-geometry.center).square().sum() for s in samples.values()])
    material=LocalMaterial(len(geometry.means),args.feature_dim,args.width,float(irradiance.median())).cuda()
    optimizer=torch.optim.Adam([
        {'params':[material.features,material.base],'lr':.005},
        {'params':[material.slopes],'lr':.0025},
        {'params':material.network.parameters(),'lr':.001}],eps=1e-8)
    rates=[g['lr'] for g in optimizer.param_groups]
    cache={}
    for ordinal,i in enumerate(fit):
        projection=geometry.project(samples[i]);projection.pop('native_rgb')
        with torch.no_grad():visibility=visibility_hint(geometry,samples[i]['light_pos'],mode='deep')
        cache[i]=(projection,visibility)
        if ordinal%50==0:print(json.dumps(dict(event='prepare_fixed_geometry',frames=ordinal+1,total=len(fit))),flush=True)
    history=(out/'history.jsonl').open('w',buffering=1);start=time.monotonic();stack=[]
    for step in range(1,args.steps+1):
        optimizer.zero_grad(set_to_none=True)
        for group,rate in zip(optimizer.param_groups,rates):group['lr']=rate*(.1**((step-1)/max(1,args.steps-1)))
        total=0.;fragments=0;chosen=[]
        for _ in range(args.local_views):
            if not stack:stack=fit.copy();random.shuffle(stack)
            i=stack.pop();chosen.append(i);sample=samples[i]
            pixels,side=patch_pixels(sample,args.local_patch,args.local_patches)
            predicted,alpha,count=render_pixels(geometry,material,sample,*cache[i],pixels,config)
            target=target_image(sample,args.background,args.display_gamma).reshape(-1,3)[pixels]
            x=predicted.reshape(args.local_patches,side,side,3);y=target.reshape_as(x)
            core=(5,side-5,5,side-5)
            l1=(x[:,5:-5,5:-5]-y[:,5:-5,5:-5]).abs().mean()
            structure=sum(1-ssim(a,b,core=core) for a,b in zip(x,y))/args.local_patches
            loss=(.8*l1+.2*structure)/args.local_views
            if not torch.isfinite(loss):raise FloatingPointError(f'Local material loss at step {step}')
            loss.backward();total+=float(loss.detach());fragments+=count
        if not all(p.grad is None or torch.isfinite(p.grad).all() for p in material.parameters()):
            raise FloatingPointError(f'Local material gradient at step {step}')
        optimizer.step()
        if step==1 or step%100==0 or step==args.steps:
            row=dict(step=step,loss=total,loss_terms=dict(photo=total),points=len(geometry.means),
                frame_indices=chosen,fragments=fragments,quadrature_queries=fragments*args.local_quadrature,
                sampled_pixels=args.local_views*args.local_patches*(args.local_patch+10)**2,
                core_pixels=args.local_views*args.local_patches*args.local_patch**2,
                seconds=time.monotonic()-start,memory_GiB=torch.cuda.max_memory_allocated()/2**30)
            history.write(json.dumps(row)+'\n');print(json.dumps(row),flush=True)
    history.close()
    torch.save(dict(kind='local_transport',config=config,step=args.steps,geometry=geometry.state_dict(),
        material=material.state_dict(),fit_indices=fit,val_indices=val),out/'last.pt')
    from plot_loss import plot_loss
    plot_loss(out/'history.jsonl');print(json.dumps(dict(event='complete',steps=args.steps)),flush=True)

@torch.no_grad()
def evaluate_local(args):
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=True;extension()
    saved=torch.load(args.checkpoint,map_location='cuda',weights_only=False);cfg=saved['config']
    if saved['kind']!='local_transport':raise ValueError('Wrong local transport checkpoint')
    if args.resolution and args.resolution!=cfg['resolution']:raise ValueError('This comparison uses the trained resolution')
    geometry=FrozenGeometry(saved['geometry']);material=LocalMaterial(len(geometry.means),cfg['feature_dim'],cfg['width']).cuda()
    material.load_state_dict(saved['material']);material.eval()
    data=SceneDataset(cfg['scene'],'train' if args.split in ['fit','validation'] else args.split,cfg['resolution'])
    indices=saved['fit_indices'] if args.split=='fit' else saved['val_indices'] if args.split=='validation' else list(range(len(data)))
    if args.limit:indices=indices[::max(1,len(indices)//args.limit)][:args.limit]
    if not indices:raise ValueError('Empty evaluation split')
    out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    perceptual=None
    if args.lpips:
        import lpips
        perceptual=lpips.LPIPS(net='vgg').cuda().eval()
    rows=[];peaks=[];components=[]
    for ordinal,i in enumerate(indices):
        torch.cuda.synchronize();render_start=time.monotonic()
        sample=to_device(data[i],'cuda');projection=geometry.project(sample)
        visibility=visibility_hint(geometry,sample['light_pos'],mode='deep')
        h,w=sample['image'].shape[:2];colors=[];alphas=[]
        for pixels in torch.arange(h*w,device='cuda').split(4096):
            rgb,alpha,_=render_pixels(geometry,material,sample,projection,visibility,pixels,cfg)
            colors.append(rgb);alphas.append(alpha)
        predicted=torch.cat(colors).reshape(h,w,3).clamp(0,1)
        target=target_image(sample,cfg['background'],cfg['display_gamma']).clamp(0,1)
        alpha=torch.cat(alphas).reshape(h,w)
        torch.cuda.synchronize();render_seconds=time.monotonic()-render_start
        x,y=(predicted*255).round()/255,(target*255).round()/255
        row=dict(frame_index=i,name=sample['name'],PSNR=float(-10*torch.log10((x-y).square().mean())),SSIM=float(ssim(x,y)),
                 silhouette_IoU=float(((alpha>.5)&(sample['alpha'][...,0]>.9)).sum()/((alpha>.5)|(sample['alpha'][...,0]>.9)).sum()))
        if perceptual is not None:row['LPIPS']=float(perceptual(x.permute(2,0,1)[None]*2-1,y.permute(2,0,1)[None]*2-1))
        row['render_seconds']=render_seconds;rows.append(row)
        if args.highlights:
            peaks.append(neutral_peak_metrics(x,y,sample['alpha']));components.append(neutral_peak_components(x,y,sample['alpha']))
        if args.save_all or args.split=='test' or ordinal<4:save_pair(out/f'pair_{ordinal:03}.png',x,y)
        if ordinal%10==0:print(json.dumps(dict(evaluated=ordinal+1,total=len(indices))),flush=True)
    report=dict(checkpoint=str(Path(args.checkpoint).resolve()),split=args.split,evaluated_frames=len(rows),
        metrics={k:sum(v[k] for v in rows)/len(rows) for k in rows[0] if k not in ['frame_index','name']},views=rows,
        protocol='Frozen GGGS geometry; exact EWA contributions; conditional Gaussian quadrature; no test fitting',
        matmul_tf32=True,save_all_test_pairs=True,
        source_geometry_fit_count=len(cfg['source_geometry_fit_indices']),material_fit_count=len(saved['fit_indices']))
    if peaks:report.update(neutral_peaks=aggregate_neutral_peak_metrics(peaks),neutral_peak_components=aggregate_neutral_peak_components(components))
    (out/'metrics.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['metrics']),flush=True)

@torch.no_grad()
def preview_local(checkpoint,output):
    """Fixed-camera light changes; only the original light has a paired target."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from PIL import Image
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=True;extension()
    saved=torch.load(checkpoint,map_location='cuda',weights_only=False);cfg=saved['config']
    if saved['kind']!='local_transport':raise ValueError('Preview requires a local material checkpoint')
    geometry=FrozenGeometry(saved['geometry']);material=LocalMaterial(len(geometry.means),cfg['feature_dim'],cfg['width']).cuda()
    material.load_state_dict(saved['material']);material.eval()
    data=SceneDataset(cfg['scene'],'test',cfg['resolution']);camera=to_device(data[0],'cuda')
    lights=np.linspace(0,len(data)-1,4,dtype=int).tolist();projection=geometry.project(camera)
    h,w=camera['image'].shape[:2];out=Path(output);out.mkdir(parents=True,exist_ok=False)
    fig,axes=plt.subplots(1,5,figsize=(15,3));axes[0].imshow(target_image(camera,cfg['background']).cpu().numpy());axes[0].set_title('GT: camera0 / light0',fontsize=9)
    rows=[]
    for ax,index in zip(axes[1:],lights):
        light=to_device(data[index],'cuda');sample=dict(camera,light_pos=light['light_pos'],light_intensity=light['light_intensity'])
        visibility=visibility_hint(geometry,sample['light_pos'],mode='deep');values=[]
        for pixels in torch.arange(h*w,device='cuda').split(4096):
            rgb,_,_=render_pixels(geometry,material,sample,projection,visibility,pixels,cfg);values.append(rgb)
        raw=torch.cat(values).reshape(h,w,3);rgb=raw.clamp(0,1).cpu()
        Image.fromarray((rgb*255).round().byte().numpy()).save(out/f'light_{index:03}.png')
        ax.imshow(rgb.numpy());ax.set_title(f'camera0 / light{index}',fontsize=9)
        rows.append({'light_frame':index,'light_position_world':sample['light_pos'].tolist(),
            'light_intensity':sample['light_intensity'].tolist(),'paired_GT_available':index==0,
            'clipped_channel_fraction':float((raw>1).float().mean())})
    for ax in axes:ax.axis('off')
    fig.tight_layout();fig.savefig(out/'relighting.png',dpi=150);plt.close(fig)
    (out/'preview.json').write_text(json.dumps({'checkpoint':str(Path(checkpoint).resolve()),'camera_frame':0,
        'camera':data.frames[0],'lights':rows,'scope':'Fixed camera, four dataset lights. Unpaired combinations are qualitative extrapolation, not scored reconstruction accuracy.'},indent=2)+'\n')
