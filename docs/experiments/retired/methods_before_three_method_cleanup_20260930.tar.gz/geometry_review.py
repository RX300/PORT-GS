"""Common-native-renderer geometry comparison and image-correspondence audit."""
from pathlib import Path
import json
import tarfile
import cv2
import numpy as np
import torch
from torch.nn import functional as F

from data import SceneDataset
from evaluate import to_device,target_image
from native_reconstruction import (author_modules,render_native,geometry_metrics,
                                   depth_reprojection,restore_native_model)


def continuous_review_model(Model, state, source_config):
    """Replay baked world geometry in the author's original numerical coordinates."""
    model=Model(0,0);means=state['params.means'];n=len(means)
    transform=source_config['training_coordinate_transform']
    center=means.new_tensor(transform['center']);scale=float(transform['scale'])
    model._xyz=((means-center)/scale).contiguous()
    model._scaling=(state['params.scales']-np.log(scale)).contiguous()
    model._rotation=state['params.quats'];model._opacity=state['params.opacities'][:,None].contiguous()
    model._features_dc=means.new_zeros(n,1,3);model._features_rest=means.new_zeros(n,0,3)
    model._sg_axis=means.new_zeros(n,0,3);model._sg_sharpness=means.new_zeros(n,0)
    model._sg_color=means.new_zeros(n,0,3)
    model.reset_3D_filter()  # The source filter is already baked into the imported covariance/opacity.
    return model


@torch.no_grad()
def review_default_geometry(checkpoint, output):
    """Separate renderer conversion from geometry changes on three fixed train views."""
    import matplotlib.pyplot as plt
    from evaluate import load_model
    from gggs_reconstruction import (author_modules as gggs_modules, relighting_state,
        restore_evaluation_model, render_evaluation_geometry)
    from native_reconstruction import depth_world_normals, boundary_metrics
    from renderer import _rasterize
    torch.set_num_threads(8)
    Model,_,backend=gggs_modules()
    final,_,saved=load_model(checkpoint);cfg=saved['config']
    if cfg.get('init_geometry_format')!='gggs':raise ValueError('Expected GGGS-initialized default checkpoint')
    source=torch.load(cfg['init_geometry'],map_location='cuda',weights_only=False)
    initial=relighting_state(source);model=restore_evaluation_model(Model,source)
    initial_replay=continuous_review_model(Model,initial,source['config'])
    final_replay=continuous_review_model(Model,final.state_dict(),source['config'])
    for a,b in zip((model.get_xyz,model.get_rotation,*model.get_scaling_n_opacity_with_3D_filter),
                   (initial_replay.get_xyz,initial_replay.get_rotation,*initial_replay.get_scaling_n_opacity_with_3D_filter)):
        torch.testing.assert_close(a,b,rtol=1e-5,atol=1e-7)
    inputs=dict(means=initial['params.means'],scales=initial['params.scales'].exp(),
                quats=initial['params.quats'],opacities=initial['params.opacities'].sigmoid())
    data=SceneDataset(cfg['scene'],'train',cfg['resolution'])
    indices=[0,len(data)//2,len(data)-1]
    out=Path(output);out.mkdir(parents=True,exist_ok=False)
    fig,axes=plt.subplots(3,5,figsize=(20,12),squeeze=False)
    direction=F.normalize(torch.tensor([.4,-.5,.8],device='cuda'),dim=0)
    rows=[]
    for row,index in enumerate(indices):
        sample=to_device(data[index],'cuda');h,w=sample['image'].shape[:2]
        results={'GGGS continuous depth':render_evaluation_geometry(model,sample,backend,source['config'])}
        replay=render_evaluation_geometry(initial_replay,sample,backend,source['config'])
        original=results['GGGS continuous depth']
        valid=(original['alpha']>.9)&(replay['alpha']>.9)&(original['depth']>0)&(replay['depth']>0)
        error=(original['depth'][valid]-replay['depth'][valid]).abs()/source['radius']
        alpha_error=(original['alpha']-replay['alpha']).abs()
        handoff=dict(alpha_max_abs=float(alpha_error.max()),alpha_mean_abs=float(alpha_error.mean()),
            alpha_p99_abs=float(alpha_error.quantile(.99)),physical_parameter_check=True,
            depth_median_abs_over_radius=float(error.median()),depth_p99_abs_over_radius=float(error.quantile(.99)),
            compared_depth_pixels=int(valid.sum()))
        # Roundtripping world/log parameters can cross discrete EWA cutoffs.
        # Bound the worst alpha change by one byte and also require small pooled error.
        if (handoff['alpha_max_abs']>1/255 or handoff['alpha_mean_abs']>1e-5
                or handoff['alpha_p99_abs']>1e-4 or handoff['depth_p99_abs_over_radius']>1e-3):
            raise ValueError(f'Continuous-depth geometry roundtrip failed: {handoff}')
        for label,values in [('Imported / default depth',inputs),('Joint final / default depth',final.raster_inputs())]:
            rendered,alpha,_=_rasterize('3dgs',**values,colors=torch.ones_like(values['means']),
                viewmats=sample['viewmat'][None],Ks=sample['K'][None],width=w,height=h,
                backgrounds=values['means'].new_zeros(1,3),render_mode='RGB+ED',packed=False)
            depth=rendered[0,...,-1];a=alpha[0,...,0]
            results[label]=dict(alpha=a,depth=depth,surface_normal=depth_world_normals(sample,depth))
        results['Joint final / GGGS depth']=render_evaluation_geometry(final_replay,sample,backend,source['config'])
        axes[row,0].imshow(target_image(sample,cfg['background'],cfg['display_gamma']).clamp(0,1).cpu())
        axes[row,0].set_title(f'Observed RGB | train {index}')
        metrics={}
        for col,(label,result) in enumerate(results.items(),1):
            a=result['alpha'];n=F.normalize(result['surface_normal'],dim=-1)
            clay=(.2+.8*(n*direction).sum(-1).abs())*a
            axes[row,col].imshow(clay.cpu(),cmap='gray',vmin=0,vmax=1)
            axes[row,col].set_title(f'{label} | train {index}')
            gt=sample['alpha'][...,0]>.9;mask=a>.5
            metrics[label]=dict(silhouette_IoU=float((gt&mask).sum()/(gt|mask).sum()),
                alpha_L1=float((a-sample['alpha'][...,0]).abs().mean()),**boundary_metrics(result,sample))
        for ax in axes[row]:ax.axis('off')
        rows.append(dict(frame_index=index,metrics=metrics,initial_continuous_roundtrip=handoff))
    fig.suptitle(f"{cfg['representation']} | joint step {saved['step']} | GGGS initialization")
    fig.tight_layout();fig.savefig(out/'geometry.png',dpi=140);plt.close(fig)
    report=dict(checkpoint=str(checkpoint),representation=cfg['representation'],step=saved['step'],
        source=cfg['init_geometry'],split='train',fixed_indices=indices,
        initial_points=len(inputs['means']),final_points=len(final.params['means']),views=rows,
        scope='No geometry GT. Three fixed train views, both initial/final expected-center-depth and initial/final GGGS continuous-depth. Imported filter is baked exactly once. Initial continuous roundtrip checked. Silhouette and roughness are proxies, not shape accuracy.')
    (out/'metrics.json').write_text(json.dumps(report,indent=2)+'\n')


def compare_geometry_buffers(reference, candidate, output):
    """Compare fixed validation cameras without reloading either author backend."""
    import matplotlib.pyplot as plt
    from evaluate import target_image
    reference,candidate,output=Path(reference),Path(candidate),Path(output)
    output.mkdir(parents=True,exist_ok=False)
    old_report=json.loads((reference/'metrics.json').read_text())
    new_report=json.loads((candidate/'metrics.json').read_text())
    if old_report['split']!=new_report['split'] or old_report['selected_geometry_frames']!=new_report['selected_geometry_frames']:
        raise ValueError('Geometry comparison requires identical splits and fixed frame indices')
    old=dict(torch.load(reference/'geometry_views.pt',map_location='cpu',weights_only=False)['frames'])
    new=dict(torch.load(candidate/'geometry_views.pt',map_location='cpu',weights_only=False)['frames'])
    cfg=json.loads((candidate.parent/'config.json').read_text())
    old_cfg=json.loads((Path(old_report['checkpoint']).parent/'config.json').read_text())
    names={'native_2dgs':'Native 2DGS','gggs_core':'GGGS core','gaussian_wrapping':'Gaussian Wrapping'}
    old_name=names.get(old_cfg['representation'],old_cfg['representation'])
    new_name=names.get(cfg['representation'],cfg['representation'])
    if old_cfg.get('prior_weight',0):old_name+=' + StableNormal'
    if cfg.get('prior_weight',0):new_name+=' + StableNormal'
    if old_cfg.get('prior_normal_weight',0) or old_cfg.get('prior_depth_weight',0):old_name+=' + normal/depth priors'
    if cfg.get('prior_normal_weight',0) or cfg.get('prior_depth_weight',0):new_name+=' + normal/depth priors'
    data=SceneDataset(cfg['scene'],'train',cfg['resolution'])
    indices=new_report['selected_geometry_frames']
    direction=F.normalize(torch.tensor([.4,-.5,.8]),dim=0)
    for normal_key,filename in [('normal','geometry_comparison.png'),
                                ('surface_normal','depth_geometry_comparison.png')]:
        fig,axes=plt.subplots(len(indices),5,figsize=(15,3*len(indices)),squeeze=False)
        closeups=[]
        for row,i in enumerate(indices):
            target=target_image(data[i],cfg['background'])
            panels=[target];labels=['Observed RGB']
            for results,name in [(old,old_name),(new,new_name)]:
                result=results[i]
                normal=F.normalize(result[normal_key],dim=-1);alpha=result['alpha']
                if alpha.shape!=target.shape[:2]:raise ValueError('Image size mismatch')
                gray=(.2+.8*(normal*direction).sum(-1).abs())*alpha
                panels.extend([gray,(normal*.5+.5)*alpha[...,None]])
                labels.extend([name+'\nclay',name+'\nnormals'])
            if normal_key=='surface_normal':
                foreground=(data[i]['alpha'][...,0]>.05)|(old[i]['alpha']>.05)|(new[i]['alpha']>.05)
                yy,xx=torch.where(foreground)
                y0,y1=max(0,int(yy.min())-8),min(target.shape[0],int(yy.max())+9)
                x0,x1=max(0,int(xx.min())-8),min(target.shape[1],int(xx.max())+9)
                closeups.append((i,[panels[k][y0:y1,x0:x1] for k in [0,1,3]]))
            for ax,values,label in zip(axes[row],panels,labels):
                ax.imshow(values.numpy(),cmap='gray' if values.ndim==2 else None,vmin=0,vmax=1)
                ax.set_title(f'{i}: {label}',fontsize=9);ax.axis('off')
        fig.suptitle('Depth-derived surface normals' if normal_key=='surface_normal' else 'Rasterized geometric normals')
        fig.tight_layout();fig.savefig(output/filename,dpi=140);plt.close(fig)
        if closeups:
            fig,axes=plt.subplots(len(indices),3,figsize=(12,4*len(indices)),squeeze=False)
            for row,(i,panels) in enumerate(closeups):
                for ax,values,label in zip(axes[row],panels,['Observed RGB',old_name,new_name]):
                    ax.imshow(values.numpy(),cmap='gray' if values.ndim==2 else None,vmin=0,vmax=1)
                    ax.set_title(f'{i}: {label}',fontsize=10);ax.axis('off')
            fig.suptitle('Depth-derived clay; shared crop includes observed and both predicted silhouettes')
            fig.tight_layout();fig.savefig(output/'depth_clay_closeup.png',dpi=140);plt.close(fig)
    report=dict(reference=str(reference.resolve()),candidate=str(candidate.resolve()),
        reference_metrics=old_report['metrics'],candidate_metrics=new_report['metrics'],
        split=new_report['split'],evaluated_frames=new_report['evaluated_frames'],fixed_frames=indices,
        note='Original cameras, fixed shared directional gray shading, predicted alpha; no geometry alignment or GT silhouette clipping. No geometry GT. Separate panels use rasterized geometric normals and depth-derived surface normals.')
    (output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def summarize_native_study(root, output):
    """Compare saved raw geometry buffers; never re-fit or mask with GT."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    torch.set_num_threads(4)
    root=Path(root);out=Path(output);out.mkdir(parents=True,exist_ok=False)
    config=json.loads((root/'validation.json').read_text())
    variants=list(config['variants'])
    scenes=[(family,scene) for family,group in config['families'].items() for scene in group['scenes']]
    summary={'root':str(root.resolve()),'scope':'Fixed saved validation views; clay uses raw predicted alpha and normals. No GT geometry or material. Topology reason counts overlap.', 'scenes':{}}
    fig,axes=plt.subplots(1,len(scenes),figsize=(6*len(scenes),4),squeeze=False)
    light=F.normalize(torch.tensor([.4,-.5,.8]),dim=0)
    for column,(family,scene) in enumerate(scenes):
        rows={};buffers={}
        for variant in variants:
            path=root/variant/family/scene
            cfg=json.loads((path/'config.json').read_text())
            history=[json.loads(line) for line in (path/'history.jsonl').read_text().splitlines()]
            terminal=history[-1]
            if terminal['step']!=cfg['steps']:raise ValueError(f'Incomplete model {path}')
            totals=terminal['topology_totals']
            expected=cfg['points']+totals['cloned']+totals['split_children']-totals['split_parents']-totals['pruned']
            if expected!=terminal['points']:raise ValueError(f'Topology accounting mismatch {path}')
            for row in history:
                event=row['topology_event']
                if event and event['after']!=event['before']+event['cloned']+event['split_children']-event['split_parents']-event['pruned']:
                    raise ValueError(f'Topology event mismatch {path} step {row["step"]}')
            rows[variant]={'checkpoint':str(path/'last.pt'),'terminal':terminal,
                'validation':json.loads((path/'validation/metrics.json').read_text())['metrics'],
                'fit':json.loads((path/'fit_full/metrics.json').read_text())['metrics'],
                'topology_accounting':'pass'}
            buffers[variant]=dict(torch.load(path/'validation/geometry_views.pt',map_location='cpu',weights_only=False)['frames'])
            axes[0,column].plot([r['step'] for r in history],[r['points'] for r in history],label=variant)
        axes[0,column].axvline(config['train']['refine-stop'],color='gray',ls='--',lw=1)
        axes[0,column].set(title=scene,xlabel='Training step',ylabel='Stored Gaussians')
        axes[0,column].legend();axes[0,column].grid(alpha=.2)
        indices=list(buffers[variants[0]])
        if any(list(buffers[v])!=indices for v in variants):raise ValueError('Geometry view selection differs')
        data=SceneDataset(cfg['scene'],'train',cfg['resolution'])
        panel,panels=plt.subplots(len(indices),len(variants)+1,figsize=(3*(len(variants)+1),3*len(indices)),squeeze=False)
        for row,index in enumerate(indices):
            panels[row,0].imshow(target_image(data[index],0).numpy())
            panels[row,0].set_title(f'GT RGB | {index}')
            for col,variant in enumerate(variants,1):
                fields=buffers[variant][index];normal=F.normalize(fields['normal'],dim=-1)
                clay=(.2+.8*(normal*light).sum(-1).abs())*fields['alpha']
                panels[row,col].imshow(clay.numpy(),cmap='gray',vmin=0,vmax=1)
                panels[row,col].set_title(f'{variant} | {index}')
            for axis in panels[row]:axis.axis('off')
        panel.tight_layout();panel.savefig(out/f'{scene}_geometry.png',dpi=130);plt.close(panel)
        summary['scenes'][scene]=rows
    fig.tight_layout();fig.savefig(out/'population.png',dpi=140);plt.close(fig)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    with tarfile.open(out/'source.tar','w') as archive:
        for name in ['geometry_review.py','diagnose_image_errors.py','native_reconstruction.py','data.py','evaluate.py']:
            archive.add(Path(__file__).parent/name,arcname=name)
    print(json.dumps({'output':str(out),'scenes':list(summary['scenes']),'topology_accounting':'pass'}),flush=True)


def correspondence_pair(source,target):
    detector=cv2.SIFT_create(nfeatures=3000)
    def detect(sample):
        image=(sample['image'].cpu().numpy()*255).round().clip(0,255).astype(np.uint8)
        gray=cv2.cvtColor(image,cv2.COLOR_RGB2GRAY)
        mask=(sample['alpha'][...,0].cpu().numpy()>.9).astype(np.uint8)*255
        return detector.detectAndCompute(gray,mask)
    ka,da=detect(source);kb,db=detect(target)
    if da is None or db is None:return np.empty((0,2),np.float32),np.empty((0,2),np.float32),{'reason':'no descriptors'}
    matches=[a for pair in cv2.BFMatcher().knnMatch(da,db,k=2) if len(pair)==2 for a,b in [pair] if a.distance<.7*b.distance]
    if len(matches)<16:return np.empty((0,2),np.float32),np.empty((0,2),np.float32),{'ratio_matches':len(matches),'reason':'too few'}
    a=np.float32([ka[m.queryIdx].pt for m in matches]);b=np.float32([kb[m.trainIdx].pt for m in matches])
    cv2.setRNGSeed(0)
    matrix,mask=cv2.findFundamentalMat(a,b,cv2.FM_RANSAC,1.,.999)
    if matrix is None or matrix.shape!=(3,3):return a[:0],b[:0],{'ratio_matches':len(matches),'reason':'F failed'}
    inliers=mask.ravel().astype(bool)
    return a[inliers],b[inliers],{'ratio_matches':len(matches),'image_F_inliers':int(inliers.sum()),
        'scope':'Classical image-F filtered matches; changing light/repeated texture may still cause false matches.'}


def feature_reprojection(source,target,result,xy):
    xy=torch.tensor(xy,device=result['depth'].device)
    h,w=result['depth'].shape
    grid=((xy+.5)/xy.new_tensor([w,h])*2-1).reshape(1,1,-1,2)
    fields=torch.stack((result['depth'],result['alpha']))
    values=F.grid_sample(fields[None],grid,align_corners=False)[0,:,0].T
    ray=torch.cat((xy+.5,torch.ones_like(xy[:,:1])),-1)@torch.linalg.inv(source['K']).T
    source_camera=ray*values[:,:1]
    world=(source_camera-source['viewmat'][:3,3])@source['viewmat'][:3,:3]
    camera=world@target['viewmat'][:3,:3].T+target['viewmat'][:3,3]
    projected=camera@target['K'].T
    projected=projected[:,:2]/projected[:,2:].clamp_min(1e-8)-.5
    valid=(values[:,0]>0)&(values[:,1]>.9)&(camera[:,2]>.01)
    return projected,valid


def calibrated_epipolar_error(source,target,a,b):
    """Independent camera check against image-F inliers, in pixel units."""
    view=target['viewmat']@torch.linalg.inv(source['viewmat'])
    t=view[:3,3]
    cross=t.new_zeros(3,3)
    cross[0,1],cross[0,2]=-t[2],t[1]
    cross[1,0],cross[1,2]=t[2],-t[0]
    cross[2,0],cross[2,1]=-t[1],t[0]
    matrix=torch.linalg.inv(target['K']).T@cross@view[:3,:3]@torch.linalg.inv(source['K'])
    x=torch.tensor(a,device=t.device)+.5;y=torch.tensor(b,device=t.device)+.5
    x=torch.cat((x,torch.ones_like(x[:,:1])),-1)
    y=torch.cat((y,torch.ones_like(y[:,:1])),-1)
    line_y=x@matrix.T;line_x=y@matrix
    numerator=(y*line_y).sum(-1).abs()
    error=.5*numerator*(line_y[:,:2].norm(dim=-1).clamp_min(1e-10).reciprocal()
                       +line_x[:,:2].norm(dim=-1).clamp_min(1e-10).reciprocal())
    return {'median_pixels':float(error.median()),'p90_pixels':float(torch.quantile(error,.9)),
            'baseline_world':float(t.norm())}


@torch.no_grad()
def compare_native_geometry(checkpoint,reference,output):
    torch.set_num_threads(4)
    Model,opt,Settings,Rasterizer=author_modules()
    current=torch.load(checkpoint,map_location='cuda',weights_only=False)
    previous=torch.load(reference,map_location='cuda',weights_only=False)
    if current['kind']!='native_2dgs' or previous['gaussians']['params.scales'].shape[1]!=2:
        raise ValueError('Expected author reconstruction versus 2D geometry')
    native=restore_native_model(Model,current)
    old=Model(0);state=previous['gaussians'];n=len(state['params.means'])
    for target,source in [('_xyz','means'),('_scaling','scales'),('_rotation','quats'),('_opacity','opacities')]:
        value=state['params.'+source]
        if target=='_opacity':value=value[:,None]
        setattr(old,target,torch.nn.Parameter(value))
    old._features_dc=torch.nn.Parameter(torch.zeros(n,1,3,device='cuda'))
    old._features_rest=torch.nn.Parameter(torch.zeros(n,0,3,device='cuda'))
    cfg=current['config'];data=SceneDataset(cfg['scene'],'train',cfg['resolution'])
    if cfg['scene']!=previous['config']['scene']:raise ValueError('Scene mismatch')
    indices=current['val_indices'];chosen=[indices[i] for i in np.linspace(0,len(indices)-1,min(4,len(indices)),dtype=int)]
    fit=current['fit_indices'];center=current['gaussians']['center'];radius=current['radius']
    origins=torch.tensor([data.frames[i]['transform_matrix'] for i in fit],device='cuda')[:,:3,3]
    directions=F.normalize(origins-center,dim=-1)
    out=Path(output);out.mkdir(parents=True,exist_ok=False)
    with tarfile.open(out/'source.tar','w') as archive:
        for filename in ['geometry_review.py','native_reconstruction.py','data.py']:
            archive.add(Path(__file__).parent/filename,arcname=filename)
    rows=[];panels=[];match_panels=[]
    for index in chosen:
        source=to_device(data[index],'cuda');direction=F.normalize(source['c2w'][:3,3]-center,dim=0)
        cosine=directions@direction
        candidates=torch.argsort(cosine,descending=True)[:8].tolist()
        neighbor_index=fit[candidates[0]]
        target=to_device(data[neighbor_index],'cuda')
        a,b,match_info=correspondence_pair(source,target)
        # Lights change between almost identical cameras. Search only eight
        # fixed nearest cameras and select by image matching, never model error.
        for candidate in candidates[1:]:
            candidate_target=to_device(data[fit[candidate]],'cuda')
            ca,cb,info=correspondence_pair(source,candidate_target)
            if len(ca)>len(a):
                neighbor_index,target,a,b,match_info=fit[candidate],candidate_target,ca,cb,info
        match_info['neighbor_selection']='most image-F inliers among 8 nearest fit cameras'
        if len(a):
            match_info['calibrated_epipolar']=calibrated_epipolar_error(source,target,a,b)
            match_info['source_xy']=a.tolist();match_info['target_xy']=b.tolist()
            match_panels.append((index,neighbor_index,source['image'].cpu(),target['image'].cpu(),a,b))
        results={};metrics={};projected={}
        for label,model in [('reference_geometry',old),('native_2dgs',native)]:
            result=render_native(model,source,Settings,Rasterizer,cfg['depth_ratio'],cfg['background'])
            neighbor=render_native(model,target,Settings,Rasterizer,cfg['depth_ratio'],cfg['background'])
            metrics[label]={'geometry':geometry_metrics(result,source,radius),
                'cross_view':depth_reprojection(source,result,target,neighbor,radius)}
            foreground=source['alpha'][...,0]>.9;background=source['alpha'][...,0]<.1
            metrics[label]['geometry'].update(
                foreground_recall=float((result['alpha'][foreground]>.5).float().mean()),
                background_opaque_fraction=float((result['alpha'][background]>.5).float().mean()))
            if len(a):projected[label]=feature_reprojection(source,target,result,a)
            results[label]={k:result[k].cpu() for k in ['rgb','normal','alpha','depth']}
        if len(a):
            valid=projected['reference_geometry'][1]&projected['native_2dgs'][1]
            for label,(xy,_) in projected.items():
                error=(xy-torch.tensor(b,device=xy.device)).norm(dim=-1)[valid]
                metrics[label]['feature_reprojection']={'common_supported_matches':len(error),
                    'median_pixels':float(error.median()) if len(error) else None,
                    'p90_pixels':float(torch.quantile(error,.9)) if len(error) else None}
        rows.append({'frame_index':index,'neighbor_fit_index':neighbor_index,'matches':match_info,'models':metrics})
        panels.append((index,target_image(source,0).cpu(),results))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(len(panels),5,figsize=(15,3*len(panels)),squeeze=False)
    light=F.normalize(torch.tensor([.4,-.5,.8]),dim=0)
    for row,(index,target,results) in enumerate(panels):
        images=[target];labels=['GT RGB']
        for label,result in results.items():
            normal=F.normalize(result['normal'],dim=-1);alpha=result['alpha']
            images.extend([(normal*.5+.5)*alpha[...,None],(.2+.8*(normal*light).sum(-1).abs())*alpha])
            labels.extend([label+' normals',label+' clay'])
        for col,(im,label) in enumerate(zip(images,labels)):
            axes[row,col].imshow(im.numpy(),cmap='gray' if im.ndim==2 else None,vmin=0,vmax=1)
            axes[row,col].set_title(f'{label} | {index}');axes[row,col].axis('off')
    fig.tight_layout();fig.savefig(out/'geometry_comparison.png',dpi=130);plt.close(fig)
    index,target,results=panels[0]
    fig,axes=plt.subplots(1,3,figsize=(12,4))
    axes[0].imshow(target.numpy());axes[0].set_title(f'Captured RGB | frame {index}')
    for axis,(label,result) in zip(axes[1:],results.items()):
        normal=F.normalize(result['normal'],dim=-1)
        clay=(.2+.8*(normal*light).sum(-1).abs())*result['alpha']
        axis.imshow(clay.numpy(),cmap='gray',vmin=0,vmax=1)
        axis.set_title(label+' | geometry-only clay')
    for axis in axes:axis.axis('off')
    fig.tight_layout();fig.savefig(out/'summary.png',dpi=120);plt.close(fig)
    if match_panels:
        fig,axes=plt.subplots(len(match_panels),2,figsize=(10,5*len(match_panels)),squeeze=False)
        for row,(index,neighbor,source,target,a,b) in enumerate(match_panels):
            for col,(frame,im,points) in enumerate([(index,source,a),(neighbor,target,b)]):
                axes[row,col].imshow(im.numpy())
                axes[row,col].scatter(points[:,0],points[:,1],c=np.arange(len(a)),cmap='turbo',s=20)
                for k,(x,y) in enumerate(points):
                    axes[row,col].text(x+2,y+2,str(k),fontsize=6,color='yellow')
                axes[row,col].set_title(f'Image-F SIFT inliers | frame {frame}');axes[row,col].axis('off')
        fig.tight_layout();fig.savefig(out/'correspondence_panel.png',dpi=130);plt.close(fig)
    report={'checkpoint':str(checkpoint),'reference':str(reference),'selected_validation_frames':chosen,
        'reference_representation':previous['config']['representation'],
        'reference_train_overlap_with_selected_validation':sorted(set(previous['fit_indices'])&set(chosen)),
        'scope':'Geometry-only comparison through one native renderer. Reported train overlap means this is not a controlled quality comparison. No reference true geometry. SIFT matches are noisy evidence, not supervision; eight camera candidates are selected without using predicted geometry.',
        'views':rows}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(rows),flush=True)
