"""Calibrated Gaussian Wrapping: oriented normals, shell densification and MVS.

Author model/CUDA: diego1401/GaussianWrapping. The normal-error accumulation
and volume-preserving flipped-normal cloning below adapt the author's
densification/normal_error.py and regularization/regularizer/normal_field.py.
No learned SDF or depth teacher. Optional StableNormal is explicitly supervised.
"""
from pathlib import Path
from types import ModuleType, SimpleNamespace
import argparse
import json
import math
import random
import subprocess
import sys
import tarfile
import time

import numpy as np
import torch
from torch.nn import functional as F

from data import SceneDataset, split_train_lights
from evaluate import to_device, target_image, ssim
from gaussians import camera_bounds
from gggs_reconstruction import centered_canvas
from native_reconstruction import depth_world_normals, reconstruction_coordinates

ROOT=Path(__file__).resolve().parent
UPSTREAM=ROOT/'third_party/GaussianWrapping'
CODE=UPSTREAM/'gaussian_wrapping'
PIPE=SimpleNamespace(debug=False,compute_cov3D_python=False,convert_SHs_python=False)


class CameraScene:
    """Small scene interface used by the author's camera-neighbor utilities."""
    def __init__(self,cameras):self.cameras=cameras
    def getTrainCameras(self):return self.cameras


def author_modules():
    if 'scene' not in sys.modules:
        scene=ModuleType('scene');scene.__path__=[str(CODE/'scene')];scene.Scene=CameraScene
        sys.modules['scene']=scene
    paths=[ROOT/'third_party/python',ROOT/'third_party/2d-gaussian-splatting/submodules/simple-knn',
           ROOT/'third_party/Geometry-Grounded-Gaussian-Splatting/submodules/warp-patch-ncc',
           *[UPSTREAM/'submodules'/name for name in ['diff-gaussian-rasterization_ours','diff-gaussian-rasterization_ms','diff-gaussian-rasterization']],CODE]
    for path in paths:sys.path.insert(0,str(path))
    from scene.gaussian_model import GaussianModel
    from arguments import OptimizationParams
    from gaussian_renderer.ours import render_ours
    from gaussian_renderer import render_depth
    from regularization.multiview_gggs import PatchMatch,compute_nearest_cameras
    from utils.general_utils import build_rotation
    parser=argparse.ArgumentParser();opt=OptimizationParams(parser).extract(parser.parse_args([]))
    opt.feature_dc_lr=.0013;opt.feature_rest_lr=.00011

    class StableMipModel(GaussianModel):
        # Same determinant compensation, evaluated as per-axis ratios. The
        # product of squared micron-scale axes otherwise underflows float32.
        def filtered(self):
            scales=self.get_scaling
            filtered=torch.hypot(scales,self.filter_3D)
            return filtered,(scales/filtered).prod(-1,keepdim=True)
        @property
        def get_scaling_n_opacity_with_3D_filter(self):
            scales,coef=self.filtered()
            return scales,self.get_opacity*coef
        @property
        def get_opacity_with_3D_filter(self):return self.get_scaling_n_opacity_with_3D_filter[1]
        @torch.no_grad()
        def reset_opacity(self):
            _,coef=self.filtered()
            opacity=torch.minimum(self.get_opacity,.01/coef.clamp_min(torch.finfo(coef.dtype).tiny))
            value=self.inverse_opacity_activation(opacity.clamp(max=.9999))
            self._opacity=self.replace_tensor_to_optimizer(value,'opacity')['opacity']
    return StableMipModel,opt,SimpleNamespace(render=render_ours,owner=render_depth,PatchMatch=PatchMatch,
        neighbors=compute_nearest_cameras,rotation=build_rotation)


def make_model(Model):
    return Model(3,use_mip_filter=True,learn_occupancy=False,use_radegs_densification=True,
                 use_appearance_network=False,n_gaussian_features=4,n_pivots_per_gaussian=2,
                 use_exposure_compensation=True)


def camera_from_sample(sample,uid=0):
    camera,_=centered_canvas(sample)
    camera.image_height,camera.image_width=sample['image'].shape[:2]
    camera.Cx=float(sample['K'][0,2])-.5;camera.Cy=float(sample['K'][1,2])-.5
    camera.R=sample['viewmat'][:3,:3].T.detach().cpu().numpy()
    camera.T=sample['viewmat'][:3,3].detach().cpu().numpy()
    camera.gray_image=(sample['image']*sample['image'].new_tensor([.299,.587,.114])).sum(-1)[None]
    camera.uid=uid;camera.image_name=sample.get('name',str(uid));camera.sample=sample
    return camera


def render_geometry(model,sample,backend,background=0.,require_depth=True,colors=None):
    canvas,grid=centered_canvas(sample)
    pkg=backend.render(canvas,model,PIPE,model.get_xyz.new_full((3,),background),
                       require_depth=require_depth,colors_precomp=colors)
    def crop(x):return F.grid_sample(x[None],grid[None],align_corners=False)[0]
    rgb=crop(pkg['render']).permute(1,2,0)
    # The local upstream Python patch retains the alpha already computed by CUDA.
    alpha=crop(pkg['mask'])[0]
    depth=crop(pkg['median_depth'])[0]
    normal=crop(pkg['normal']).permute(1,2,0)@sample['viewmat'][:3,:3]
    derived=depth_world_normals(sample,depth)*alpha.detach()[...,None]
    return dict(rgb=rgb,alpha=alpha,depth=depth,normal=normal,surface_normal=derived,
                screen=pkg['viewspace_points'],visible=pkg['visibility_filter'],radii=pkg['radii'])


def mvs_package(result,sample):
    depth=result['depth'][None]*(sample['alpha'][...,0]>.9)[None]
    normal=(result['normal']@sample['viewmat'][:3,:3].T).permute(2,0,1)
    return dict(median_depth=depth,expected_depth=depth,normal=normal)


def normal_prior_loss(result,sample,target_camera,valid):
    """Teacher constrains actual geometry and depth, not free normal features."""
    target=target_camera@sample['viewmat'][:3,:3]
    normal=F.normalize(result['normal'],dim=-1)
    derived=F.normalize(result['surface_normal'],dim=-1)
    error=.5*(2-(normal*target).sum(-1).clamp(-1,1)-(derived*target).sum(-1).clamp(-1,1))
    return (error*valid).sum()/valid.sum().clamp_min(1)


@torch.no_grad()
def wrap_shell(model, samples, backend, quantile=.05):
    """Author count-normalized max-contributor error and flipped shell clone."""
    n=len(model._xyz);errors=model._xyz.new_zeros(n)
    normals=F.normalize(model.convert_features_to_normals(),dim=-1)
    for sample in samples:
        result=render_geometry(model,sample,backend,colors=normals)
        target=F.normalize(result['surface_normal'],dim=-1)
        valid=(result['depth']>0)&(sample['alpha'][...,0]>.9)
        canvas,grid=centered_canvas(sample)
        ownership=backend.owner(canvas,model,PIPE,model._xyz.new_zeros(3))['gidx'].float()
        if ownership.ndim==2:ownership=ownership[None]
        ids=F.grid_sample(ownership[None],grid[None],mode='nearest',align_corners=False)[0,0].long()
        valid &= (ids>=0)&(ids<n)
        error=(1-(result['rgb']*target).sum(-1))*valid
        sums=errors.new_zeros(n).index_add_(0,ids[valid],error[valid])
        counts=errors.new_zeros(n).index_add_(0,ids[valid],torch.ones_like(error[valid]))
        errors+=sums/counts.clamp_min(1)
    errors/=len(samples)
    selected=errors>torch.quantile(errors,1-quantile)
    count=int(selected.sum())
    if not count:return dict(cloned=0,max_error=float(errors.max()))
    local=backend.rotation(model._rotation[selected]).transpose(-1,-2)
    projection=(normals[selected,None]*local).sum(-1)
    model._scaling[selected]+=math.log(.5)*projection.square()
    scales=model.get_scaling_with_3D_filter[selected]
    # Standard deviation along the normal under the adjusted covariance.
    std=(projection.square()*scales.square()).sum(-1,keepdim=True).sqrt()
    xyz=model._xyz[selected]-.1*std*normals[selected]
    model._xyz[selected]+=.1*std*normals[selected]
    features=model._gaussian_features[selected].clone();features[:,-1]*=-1
    model.densify_and_clone_from_mask(selected,new_xyz=xyz,new_gaussian_features=features)
    return dict(cloned=count,max_error=float(errors.max()),quantile_error=float(torch.quantile(errors,1-quantile)))


def restore_model(Model,saved):
    model=make_model(Model);model.restore(saved['capture'],SimpleNamespace(**saved['config']['optimizer']))
    with torch.no_grad():
        for attr,key in [('_xyz','means'),('_scaling','scales'),('_rotation','quats'),('_opacity','opacities')]:
            value=saved['gaussians']['params.'+key]
            getattr(model,attr).copy_(value[:,None] if attr=='_opacity' else value)
    model.filter_3D=saved['world_filter_3D'];model.init_culling(1)
    return model


def train_wrapping(args):
    torch.set_num_threads(8);torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
    Model,opt,backend=author_modules();opt.iterations=args.steps;opt.position_lr_max_steps=args.steps
    opt.densify_until_iter=args.refine_stop
    out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    data=SceneDataset(args.scene,'train',args.resolution);fit,val=split_train_lights(data.frames)
    cpu={i:data[i] for i in fit};center,radius=camera_bounds(list(cpu.values())[::max(1,len(fit)//32)])
    origins=torch.stack([s['c2w'][:3,3] for s in cpu.values()]);scale=float(1.1*(origins-origins.mean(0)).norm(dim=-1).max())
    from surface_initialization import prepare_mask_surface
    print('Preparing fit-only occupancy initialization',flush=True)
    seeds=prepare_mask_surface(data,fit,val,args.points,args.wrapping_init_grid,2,.95,args.seed,'occupancy')
    xyz=(seeds['positions'].numpy()-center.numpy())/scale
    samples={i:reconstruction_coordinates(to_device(s,'cuda'),center.cuda(),scale) for i,s in cpu.items()}
    cameras=[camera_from_sample(samples[i],k) for k,i in enumerate(fit)]
    filter_cameras=[centered_canvas(samples[i])[0] for i in fit]
    model=make_model(Model)
    model.create_from_pcd(SimpleNamespace(points=xyz,colors=np.full_like(xyz,.5),normals=np.zeros_like(xyz)),1.)
    model.initialize_exposure_compensation(len(fit));model.training_setup(opt);model.init_culling(len(fit))
    model.compute_3D_filter(filter_cameras)
    neighbors=backend.neighbors(cameras)
    matcher=backend.PatchMatch(3,1.,0.,PIPE)
    prior=None
    if args.wrapping_prior_weight:
        from surface import SurfacePriors
        prior=SurfacePriors(args.wrapping_normal_priors,data,fit,need_depth=False)
    config=dict(representation='gaussian_wrapping',geometry='3dgs',scene=str(data.scene_path.resolve()),
        resolution=args.resolution,steps=args.steps,seed=args.seed,background=args.background,depth_ratio=0.,
        sh_degree=3,sdf=False,geometry_priors=prior is not None,mip_filter=True,optimizer=vars(opt),
        wrapping_start=args.wrapping_start,wrap_densify_start=args.wrapping_densify_start,
        wrap_densify_end=args.wrapping_densify_end,regularize_from=args.wrapping_regularize_from,
        prior_weight=args.wrapping_prior_weight,normal_priors=args.wrapping_normal_priors,init_grid=args.wrapping_init_grid,
        training_coordinate_transform=dict(scale=scale,center=center.tolist()),
        upstream_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=UPSTREAM,text=True).strip(),
        protocol='Oriented normals + five shell densification events + author slow MVS + exposure L1; fit-only masks, no SDF',
        adjustments=['NRHints fit-only mask seeds instead of SfM','full K via centered virtual canvas and cropped fields',
            'mask L1 .2','stable per-axis Mip determinant ratio','MVS slow depth-map path for full K',
            'shell errors only on supplied foreground; nearest resampling of contributor IDs',
            'raw RGB evaluation without fitting validation exposures'])
    (out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
    (out/'split.json').write_text(json.dumps(dict(fit=fit,validation=val),indent=2)+'\n')
    with tarfile.open(out/'upstream_source.tar','w') as a:
        for p in CODE.rglob('*.py'):a.add(p,arcname=str(p.relative_to(UPSTREAM)))
        for p in (CODE/'configs').rglob('*.yaml'):a.add(p,arcname=str(p.relative_to(UPSTREAM)))
    hist=(out/'history.jsonl').open('w',buffering=1);stack=[];start=time.monotonic();wrap_events=[]
    print(json.dumps(dict(event='initialized_wrapping',points=len(xyz),fit=len(fit),validation=len(val),gpu=torch.cuda.get_device_name())),flush=True)
    for step in range(1,args.steps+1):
        model.update_learning_rate(step)
        if step%1000==0:model.oneupSHdegree()
        if not stack:stack=list(range(len(fit)))
        k=stack.pop(random.randrange(len(stack)));index=fit[k];sample=samples[index]
        active=step>=args.wrapping_regularize_from
        if step==args.wrapping_start:model.reset_normal_features()
        result=render_geometry(model,sample,backend,args.background,active)
        target=target_image(sample,args.background)
        exposure=model.get_appearance_embedding(k)
        photo=.8*(result['rgb']*exposure[0].exp()+exposure[1]-target).abs().mean()+.2*(1-ssim(result['rgb'],target))
        terms=dict(photo=photo,silhouette=.2*(result['alpha']-sample['alpha'][...,0]).abs().mean())
        dn=F.normalize(result['surface_normal'],dim=-1)
        valid=(sample['alpha'][...,0]>.9)&(result['alpha'].detach()>.9)&(result['depth'].detach()>0)
        valid=F.avg_pool2d(valid.float()[None,None],3,1,1)[0,0]==1
        if active:
            terms['normal']=.05*((1-(result['normal']*dn).sum(-1))*valid).mean()
            ids=neighbors[k]['nearest_id']
            if ids:
                other=random.choice(ids);neighbor=samples[fit[other]]
                nr=render_geometry(model,neighbor,backend,args.background)
                ncc,geo=matcher(cameras[k],cameras[other],mvs_package(result,sample),mvs_package(nr,neighbor),depth_ratio=.6,znear=.02)
                terms['ncc']=.6*ncc.squeeze();terms['multiview_geo']=.02*geo.squeeze()
        if step>=args.wrapping_start:
            oriented=render_geometry(model,sample,backend,colors=model.convert_features_to_normals())
            terms['wrap_normal']=.05*.6*((1-(oriented['rgb']*dn).sum(-1))*valid).mean()
        if prior is not None and active:
            terms['stable_normal']=args.wrapping_prior_weight*normal_prior_loss(result,sample,prior.frame(index,'cuda')['normal'],valid)
        loss=sum(terms.values())
        if not torch.isfinite(loss):raise FloatingPointError(f'Wrapping loss at {step}')
        loss.backward()
        parameters=[p for group in model.optimizer.param_groups for p in group['params'] if p.grad is not None]
        if not bool(torch.stack([torch.isfinite(p.grad).all() for p in parameters]).all()):
            raise FloatingPointError(f'Wrapping gradient at {step}')
        with torch.no_grad():
            event=None
            if step<opt.densify_until_iter:
                visible=result['visible'];model.max_radii2D[visible]=torch.maximum(model.max_radii2D[visible],result['radii'][visible])
                model.add_densification_stats_radegs(result['screen'],visible)
                if step>opt.densify_from_iter and step%opt.densification_interval==0:
                    event=model.densify_and_prune_radegs(opt.densify_grad_threshold,.05,1.,None,use_abs_grad=True,viewpoint_cameras=filter_cameras)
                    model.compute_3D_filter(filter_cameras)
                if step%opt.opacity_reset_interval==0:model.reset_opacity()
            if args.wrapping_densify_start<=step+1<=args.wrapping_densify_end and (step+1-args.wrapping_densify_start)%1000==0:
                event=wrap_shell(model,list(samples.values()),backend);event.update(step=step,kind='wrapping_shell')
                wrap_events.append(event);model.compute_3D_filter(filter_cameras)
                print(json.dumps(event),flush=True)
            elif step>=opt.densify_until_iter and step%100==0 and step<args.steps-100:
                model.compute_3D_filter(filter_cameras)
            if step<args.steps:model.optimizer.step();model.optimizer.zero_grad(set_to_none=True)
            if step==1 or step%100==0 or step==args.steps:
                row=dict(step=step,frame_index=index,loss=float(loss),loss_terms={k:float(v) for k,v in terms.items()},
                         points=len(model._xyz),topology_event=event,seconds=time.monotonic()-start)
                hist.write(json.dumps(row)+'\n');print(json.dumps(row),flush=True)
    hist.close()
    geometry={'center':center.cuda(),'params.means':model._xyz*scale+center.cuda(),
              'params.scales':model._scaling+math.log(scale),'params.quats':model._rotation,'params.opacities':model._opacity[:,0]}
    torch.save(dict(kind='gaussian_wrapping',config=config,step=args.steps,capture=model.capture(),gaussians=geometry,
                    world_filter_3D=model.filter_3D*scale,radius=radius,fit_indices=fit,val_indices=val,
                    camera_offsets=None,wrapping_events=wrap_events),out/'last.pt')
    from plot_loss import plot_loss
    plot_loss(out/'history.jsonl')
    print(json.dumps(dict(event='complete',steps=args.steps,seconds=time.monotonic()-start)),flush=True)
