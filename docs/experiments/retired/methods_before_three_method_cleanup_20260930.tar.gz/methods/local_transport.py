"""Per-contribution local total light response; not an identified physical BRDF."""
import math
import torch
from torch import nn
from torch.nn import functional as F
from .base import direction_encoding

class LocalMaterial(nn.Module):
    def __init__(self,count,feature_dim=16,width=64,light_scale=1.):
        super().__init__()
        self.features=nn.Parameter(torch.randn(count,feature_dim)*.01)
        self.slopes=nn.Parameter(torch.zeros(count,3,feature_dim))
        self.base=nn.Parameter(torch.zeros(count,3))
        self.register_buffer('light_scale',torch.tensor(float(light_scale)))
        self.register_buffer('roughness',torch.tensor([.04,.08,.16,.3,.6,1.]))
        self.network=nn.Sequential(nn.Linear(feature_dim+74,width),nn.SiLU(),
            nn.Linear(width,width),nn.SiLU(),nn.Linear(width,3))
        nn.init.normal_(self.network[-1].weight,std=.01);nn.init.constant_(self.network[-1].bias,-1.5)

    def forward(self,geometry,gid,positions,u,rotation,masses,sample,visibility):
        # All positions are in the same normalized geometry coordinates.
        light=(sample['light_pos']-geometry.center)/geometry.world_scale
        eye=(sample['c2w'][:3,3]-geometry.center)/geometry.world_scale
        incoming=light-positions;outgoing=eye-positions
        wi=F.normalize(incoming,dim=-1);wo=F.normalize(outgoing,dim=-1)
        local_wi=torch.einsum('mqi,mij->mqj',wi,rotation)
        local_wo=torch.einsum('mqi,mij->mqj',wo,rotation)
        local_h=F.normalize(local_wi+local_wo,dim=-1)
        axis=geometry.scales[gid].argmin(-1)
        n=F.one_hot(axis,3).to(wi.dtype)[:,None].expand_as(wi)
        n=n*torch.where((n*local_wo).sum(-1,keepdim=True)>=0,1.,-1.)
        nl=(n*local_wi).sum(-1,keepdim=True);nv=(n*local_wo).sum(-1,keepdim=True)
        nh=(n*local_h).sum(-1,keepdim=True)
        reflection=2*n*nl-local_wi
        a2=self.roughness.pow(4)
        ggx=a2/(math.pi*(nh.square()*(a2-1)+1).square().clamp_min(1e-12))
        ggx=torch.log1p(ggx)*((nl>0)&(nv>0))/10
        coord=u.tanh()
        code=self.features[gid,None]+torch.einsum('mqi,mif->mqf',coord,self.slopes[gid])
        d2=incoming.square().sum(-1,keepdim=True)*geometry.world_scale.square()
        distance=(d2.sqrt()/geometry.world_radius).log()
        hint=visibility[gid,None,None].expand_as(distance)
        inputs=torch.cat((code,coord,direction_encoding(local_wi),direction_encoding(local_wo),
                          local_h,reflection,nl,nv,nh,ggx,distance,hint),-1)
        response=F.softplus(self.network(inputs)+self.base[gid,None])
        radiance=response*sample['light_intensity']/(d2.clamp_min(1e-12)*self.light_scale)
        return (radiance*masses[None,:,None]).sum(1)
