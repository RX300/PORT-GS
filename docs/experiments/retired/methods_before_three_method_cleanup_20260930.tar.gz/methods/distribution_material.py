"""Image-supervised, normalized spatial/angular transport on 2DGS.

8DNA-inspired energy/density factorization, not its path-supervised flow.
The discrete spatial measure is opacity times surfel area; the continuous
directional measure is solid angle. No light values enter density parameters.
"""
import math

import torch
from torch import nn
from torch.nn import functional as F

from materials.ggx import GGXMaterial
from .base import TransportBase, direction_encoding, quadrature_mass
from .neural_material import NeuralMaterialTransport


def vmf_density(cosine, kappa):
    """Normalized S2 von Mises-Fisher PDF, including the uniform limit."""
    safe = kappa.clamp_min(1e-4)
    scale = safe / (-torch.expm1(-2 * safe) * (2 * math.pi))
    return scale * torch.exp(safe * (cosine.clamp(-1, 1) - 1))


def image_distribution_loss(predicted, target):
    """Per-channel spatial KL in observed image space (not path likelihood).

    RGB regression separately identifies total energy. Black channels contribute
    zero. Both inputs use the existing observation transform, without claiming
    calibrated photon counts from these camera images.
    """
    p = predicted.reshape(-1, 3).clamp_min(0) + 1e-6
    t = target.reshape(-1, 3).clamp_min(0)
    q = t / t.sum(0, keepdim=True).clamp_min(1e-6)
    log_p = p.log() - p.sum(0, keepdim=True).log()
    return (q * (q.clamp_min(1e-12).log() - log_p)).sum(0).mean()


class DistributionMaterialTransport(TransportBase):
    geometry = '2dgs'
    requires_normals = True
    defaults = dict(feature_dim=24, width=64, rank=32, distribution_weight=.03)
    cli_fields = tuple(defaults)

    def __init__(self, feature_dim=24, width=64, rank=32,
                 distribution_weight=.03, light_scale=1.):
        super().__init__(light_scale)
        if feature_dim < 9 or rank < 1 or distribution_weight < 0:
            raise ValueError('Distribution material requires >=9 features, rank>=1 and nonnegative KL weight')
        self.rank = rank
        self.distribution_weight = distribution_weight
        self.decoder = GGXMaterial()
        self.anchor_centers = nn.Parameter(torch.empty(rank, 3).uniform_(-.5, .5))
        self.log_width = nn.Parameter(torch.full((rank,), math.log(.2)))
        # RGB receiver mixtures and energy depend on the outgoing configuration.
        self.receiver_net = nn.Sequential(
            nn.Linear(feature_dim + 54, width), nn.SiLU(),
            nn.Linear(width, width), nn.SiLU(), nn.Linear(width, rank * 3 + 3))
        nn.init.normal_(self.receiver_net[-1].weight, std=.001)
        nn.init.zeros_(self.receiver_net[-1].bias)
        with torch.no_grad():
            self.receiver_net[-1].bias[-3:].fill_(-2.)
        # Each mixture component has its own direction; spatial feature offsets
        # make p(w_i | x_i,k) nonseparable in incident position and direction.
        self.source_net = nn.Sequential(nn.Linear(feature_dim, width), nn.SiLU(),
                                        nn.Linear(width, 4))
        nn.init.zeros_(self.source_net[-1].weight)
        nn.init.zeros_(self.source_net[-1].bias)
        self.direction_axes = nn.Parameter(F.normalize(torch.randn(rank, 3), dim=-1))
        self.raw_kappa = nn.Parameter(torch.full((rank,), -1.))

    material_normal = staticmethod(NeuralMaterialTransport.material_normal)
    material_response = NeuralMaterialTransport.material_response

    @torch.no_grad()
    def initialize_material(self, gaussians):
        features = gaussians.params['features']
        features[:, :6].copy_(torch.logit(GGXMaterial.initial_latent(features)))
        features[:, 6:9].zero_()

    def point_light(self, points, light_pos, intensity, visibility):
        delta = light_pos - points
        incident = intensity[None] / self.light_scale / delta.square().sum(-1, keepdim=True)
        return incident * visibility[:, None], F.normalize(delta, dim=-1)

    def source_distribution(self, xyz, features, mass, direction):
        distance2 = (xyz[:, None] - self.anchor_centers[None]).square().sum(-1)
        logits = -distance2 / (2 * self.log_width.exp().square())
        probability = (logits + mass.log()[:, None]).softmax(dim=0)
        parameters = self.source_net(features)
        axes = F.normalize(self.direction_axes[None] + parameters[:, None, :3], dim=-1)
        kappa = .05 + 32 * torch.sigmoid(self.raw_kappa[None] + parameters[:, 3:4])
        angular = vmf_density((axes * direction[:, None]).sum(-1), kappa)
        return probability, angular

    def receiver_distribution(self, xyz, features, direction):
        inputs = torch.cat((features, direction_encoding(xyz), direction_encoding(direction)), -1)
        parameters = self.receiver_net(inputs)
        mixture = parameters[:, :-3].reshape(-1, self.rank, 3).softmax(dim=1)
        energy = parameters[:, -3:].sigmoid()
        return mixture, energy

    def forward(self, gaussians, receivers, eye, light_pos, light_intensity,
                source_visibility, port_active=True):
        incident, wi = self.point_light(receivers['means'], light_pos, light_intensity,
                                        receivers['visibility'])
        wo = F.normalize(eye - receivers['means'], dim=-1)
        specular, diffuse = self.material_response(receivers, wi, wo)
        direct = incident * (specular + diffuse)
        if not port_active:
            return direct
        params = gaussians.params
        source_incident, source_wi = self.point_light(params['means'], light_pos,
                                                     light_intensity, source_visibility)
        source_xyz = (params['means'] - gaussians.center) / gaussians.radius
        probability, angular = self.source_distribution(
            source_xyz, params['features'], quadrature_mass(params), source_wi)
        # p(x_i|k) already includes the discrete quadrature measure. The angular
        # PDF includes the incident cosine conceptually; do not multiply it twice.
        incoming = (probability * angular).T @ source_incident
        receiver_xyz = (receivers['means'] - gaussians.center) / gaussians.radius
        mixture, energy = self.receiver_distribution(receiver_xyz, receivers['features'], wo)
        indirect = energy * torch.einsum('mkc,kc->mc', mixture, incoming)
        return direct + indirect
