"""Explicit registry shared by training, evaluation and checkpoints."""
import argparse

from .anchor import AnchorTransport
from .base import PortTransport, TransportBase
from .directional import DirectionalTransport
from .attention import SurfaceAttention
from .neural_material import NeuralMaterialTransport
from .distribution_material import DistributionMaterialTransport


METHODS = {
    "learned_anchor_exchange": AnchorTransport,
    "directional_port_v1": DirectionalTransport,
    "surface_attention": SurfaceAttention,
    "neural_material": NeuralMaterialTransport,
    "distribution_material": DistributionMaterialTransport,
}
DEFAULT_METHOD = "directional_port_v1"


class NativeReconstructionOptions:
    defaults = dict(native_sh_degree=3, native_depth_ratio=0.,
                    native_normal_weight=.05, native_distortion_weight=0.,
                    native_mask_weight=0., native_coordinate_scale='world', native_init='mask',
                    native_topology='corrected', native_split_extent='camera')
    cli_fields = tuple(defaults)


class GroundedReconstructionOptions:
    defaults = dict(gggs_normal_weight=.05, gggs_mask_weight=.2, gggs_regularize_from=7000,
                    gggs_prior_normal_weight=0., gggs_prior_depth_weight=0.,
                    gggs_prior_from=1000, gggs_prior_warmup=2000)
    cli_fields = tuple(defaults)


class WrappingOptions:
    defaults = dict(wrapping_start=20001, wrapping_regularize_from=7000,
                    wrapping_densify_start=22000, wrapping_densify_end=26000,
                    wrapping_prior_weight=0., wrapping_normal_priors='', wrapping_init_grid=192)
    cli_fields = tuple(defaults)


RECONSTRUCTIONS = {'native_2dgs': NativeReconstructionOptions, 'gggs_core': GroundedReconstructionOptions,
                   'gaussian_wrapping': WrappingOptions}

class LocalRelightingOptions:
    defaults=dict(feature_dim=16,width=64,local_views=2,local_patch=16,local_patches=2,
                  local_quadrature=3,local_shader_chunk=131072)
    cli_fields=tuple(defaults)

RELIGHTING_PIPELINES={'local_transport':LocalRelightingOptions}


def method_class(config):
    # Pre-directional checkpoints did not record representation.
    name = config.get("representation", "learned_anchor_exchange")
    if name not in METHODS:
        raise ValueError(f"Unknown transport method: {name}")
    return METHODS[name]


def resolve_config(config):
    cls = method_class(config)
    geometry = '3dgs' if config.get('init_geometry_format') == 'gggs' else cls.geometry
    return {**cls.defaults, **config, "geometry": geometry}


def build_transport(config, light_scale):
    config = resolve_config(config)
    cls = method_class(config)
    return cls(**{key: config[key] for key in cls.defaults}, light_scale=light_scale)


def add_method_arguments(parser, argv=None):
    selector = argparse.ArgumentParser(add_help=False)
    choices = {**METHODS, **RECONSTRUCTIONS, **RELIGHTING_PIPELINES}
    selector.add_argument("--representation", choices=choices, default=DEFAULT_METHOD)
    selection, _ = selector.parse_known_args(argv)
    parser.add_argument("--representation", choices=choices, default=DEFAULT_METHOD,
                        help="registered transport method; use METHOD --help for its options")
    cls = choices[selection.representation]
    group = parser.add_argument_group(f"{selection.representation} parameters")
    for field in cls.cli_fields:
        default = cls.defaults[field]
        group.add_argument("--" + field.replace("_", "-"), type=type(default), default=default)
