"""Exact frozen GGGS EWA fragments, with original off-center camera sampling."""
from pathlib import Path
import math
import torch
from torch import nn
from torch.nn import functional as F
from gsplat.utils import normalized_quat_to_rotmat
from gggs_reconstruction import author_modules,centered_canvas
from native_reconstruction import reconstruction_coordinates

ROOT=Path(__file__).resolve().parent
_EXT=None

def extension():
    global _EXT
    if _EXT is None:
        from torch.utils.cpp_extension import load
        build=ROOT/'third_party/local_fragments_build';build.mkdir(exist_ok=True)
        _EXT=load('port_local_fragments',sources=[str(ROOT/'csrc/local_fragments.cu')],
                  build_directory=str(build),extra_cuda_cflags=['-O3','-std=c++17'],
                  extra_cflags=['-O3','-std=c++17'],verbose=False)
    return _EXT

class FrozenGeometry(nn.Module):
    geometry='3dgs'
    def __init__(self,state):
        super().__init__()
        for key,value in state.items():self.register_buffer(key,value.detach().clone())
        self.radius=float(self.world_radius)

    @classmethod
    def from_gggs(cls,saved):
        cfg=saved['config'];scale=cfg['training_coordinate_transform']['scale']
        raw=saved['capture'][5].exp();filt=saved['world_filter_3D']/scale
        filtered=torch.sqrt(raw.square()+filt.square())
        # Preserve the original author's opacity compensation exactly.
        coefficient=torch.sqrt(raw.square().prod(-1)/filtered.square().prod(-1))
        return cls(dict(means=saved['capture'][2],scales=filtered,
            quats=F.normalize(saved['capture'][6],dim=-1),
            opacities=saved['capture'][7][:,0].sigmoid()*coefficient,
            center=saved['gaussians']['center'],world_scale=raw.new_tensor(scale),
            world_radius=raw.new_tensor(saved['radius'])))

    def raster_inputs(self):
        return dict(means=self.means*self.world_scale+self.center,scales=self.scales*self.world_scale,
                    quats=self.quats,opacities=self.opacities)

    def local_sample(self,sample):
        return reconstruction_coordinates(sample,self.center,float(self.world_scale))

    @torch.no_grad()
    def project(self,sample,colors=None):
        author_modules()
        from diff_gaussian_rasterization import _C
        local=self.local_sample(sample);camera,grid=centered_canvas(local)
        empty=self.means.new_empty(0)
        if colors is None:colors=torch.ones_like(self.means)
        result=_C.rasterize_gaussians(self.means.new_zeros(3),self.means,colors.contiguous(),
            self.opacities[:,None].contiguous(),self.scales,self.quats,empty,empty,empty,empty,empty,
            0,0,1.,camera.world_view_transform,camera.full_proj_transform,
            math.tan(camera.FoVx/2),math.tan(camera.FoVy/2),0.,camera.image_height,camera.image_width,
            camera.camera_center,False,False,False)
        rendered,rgb,alpha,_,_,_,geom,bins,_,tiles=result
        count=((camera.image_width+15)//16)*((camera.image_height+15)//16)
        means,conics,ranges,ids=_C.fragment_data(geom,bins,tiles,len(self.means),rendered,count)
        native=F.grid_sample(rgb[None],grid[None],align_corners=False)[0].permute(1,2,0)
        a=F.grid_sample(alpha[None],grid[None],align_corners=False)[0,0]
        return dict(means=means,conics=conics,ranges=ranges,ids=ids,
                    width=camera.image_width,height=camera.image_height,
                    original_width=sample['image'].shape[1],
                    shift=sample['K'].new_tensor([camera.image_width/2,camera.image_height/2])-sample['K'][:2,2],
                    alpha=a,native_rgb=native)

@torch.no_grad()
def gather(projected,pixels):
    w=projected['original_width'];xy=torch.stack((pixels%w,pixels//w),-1).float()+projected['shift']
    low=xy.floor();fraction=xy-low
    offsets=xy.new_tensor([[0,0],[1,0],[0,1],[1,1]])
    points=(low[:,None]+offsets).reshape(-1,2).int().contiguous()
    f=fraction[:,None];weights=torch.where(offsets[None]>0,f,1-f).prod(-1).flatten()
    owner=torch.arange(len(pixels),device=pixels.device)[:,None].expand(-1,4).flatten()
    keep=weights>0;points=points[keep];weights=weights[keep];owner=owner[keep]
    gid,qid,alpha_weight,counts=extension().gather(projected['means'],projected['conics'],
        projected['ranges'],projected['ids'],points,projected['width'],projected['height'])
    return dict(gid=gid,qid=qid,weights=alpha_weight,counts=counts,xy=points,
                query_weight=weights,owner=owner,pixel_count=len(pixels))

def composite(colors,fragments,background=0.):
    weights=fragments['weights'];counts=fragments['counts'].long()
    values=torch.cat((colors*weights[:,None],weights[:,None]),-1)
    summed=torch.segment_reduce(values,'sum',lengths=counts)
    result=values.new_zeros(fragments['pixel_count'],4).index_add(0,fragments['owner'],
        summed*fragments['query_weight'][:,None])
    return result[:,:3]+background*(1-result[:,3:]),result[:,3:]

@torch.no_grad()
def quadrature(geometry,sample,projected,fragments,nodes=3):
    """Conditional Gaussian along each canvas ray, not a center/surface hit."""
    local=geometry.local_sample(sample);gid=fragments['gid'];qid=fragments['qid']
    uv=fragments['xy'].float()+.5
    uv[:,0]-=projected['width']/2;uv[:,1]-=projected['height']/2
    rays=torch.cat((uv/sample['K'].diag()[:2],torch.ones_like(uv[:,:1])),-1)@local['viewmat'][:3,:3]
    origin=local['c2w'][:3,3];R=normalized_quat_to_rotmat(geometry.quats[gid])
    delta=origin-geometry.means[gid]
    a=(rays[qid,:,None]*R).sum(1)/geometry.scales[gid]
    b=(delta[:,:,None]*R).sum(1)/geometry.scales[gid]
    precision=a.square().sum(-1);mean=-(a*b).sum(-1)/precision
    sigma=precision.rsqrt()
    node=mean.new_tensor([0.]) if nodes==1 else mean.new_tensor([-3**.5,0.,3**.5])
    mass=mean.new_tensor([1.]) if nodes==1 else mean.new_tensor([1/6,2/3,1/6])
    t=mean[:,None]+sigma[:,None]*node
    positions=origin+rays[qid,None]*t[...,None]
    u=b[:,None]+a[:,None]*t[...,None]
    return positions,u,R,mass
