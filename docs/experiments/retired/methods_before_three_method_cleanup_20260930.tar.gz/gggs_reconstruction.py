"""Geometry-Grounded GS core adapter for calibrated moving-light captures.

Uses the author's continuous-depth CUDA renderer and Gaussian model. This is a
controlled core ablation, not a reproduction of the paper's complete pipeline:
no NCC pseudo-supervision, exposure fitting or SDF. Frozen normal/depth priors
are optional and explicitly recorded in each experiment.
"""
from pathlib import Path
from types import ModuleType, SimpleNamespace
import argparse
import json
import math
import random
import subprocess
import sys
import tarfile
import time

import numpy as np
import torch
from torch.nn import functional as F

from data import SceneDataset, split_train_lights
from evaluate import to_device, target_image, ssim
from gaussians import camera_bounds
from native_reconstruction import projection_from_K, depth_world_normals, reconstruction_coordinates

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT/'third_party/Geometry-Grounded-Gaussian-Splatting'


@torch.no_grad()
def relighting_state(saved):
    """Filtered GGGS geometry in the default renderer's world/log parameterization.

    This preserves the 3D covariance and opacity compensation, not the author's
    radial sorting, EWA footprint or continuous-depth rendering equations.
    """
    if saved['kind'] != 'gggs_core':
        raise ValueError('Expected a GGGS geometry checkpoint')
    from local_fragments import FrozenGeometry
    geometry = FrozenGeometry.from_gggs(saved)
    values = geometry.raster_inputs()
    return {'center': geometry.center, 'params.means': values['means'],
            'params.scales': values['scales'].log(), 'params.quats': values['quats'],
            'params.opacities': torch.logit(values['opacities'])}


def author_modules():
    # Load the author's model package without running its unrelated dataset
    # loader (which imports Open3D). All model/appearance modules are real files.
    if 'scene' not in sys.modules:
        package=ModuleType('scene');package.__path__=[str(UPSTREAM/'scene')]
        sys.modules['scene']=package
    for path in [ROOT/'third_party/python',
                 ROOT/'third_party/2d-gaussian-splatting/submodules/simple-knn',
                 UPSTREAM/'submodules/diff-gaussian-rasterization',UPSTREAM]:
        sys.path.insert(0,str(path))
    from scene.gaussian_model import GaussianModel
    from arguments import OptimizationParams
    from gaussian_renderer import render
    parser=argparse.ArgumentParser()
    opt=OptimizationParams(parser).extract(parser.parse_args([]))
    return GaussianModel,opt,render


def centered_canvas(sample):
    """Recenter by rendering a larger virtual sensor; preserve original rays.

    Upstream CUDA assumes centered principal points even when its projection
    matrix is off-center. Sampling the centered canvas avoids changing CUDA.
    There is one bilinear resampling of rendered fields, no input resampling.
    """
    h,w=sample['image'].shape[:2];K=sample['K']
    cx,cy=float(K[0,2]),float(K[1,2])
    width=2*math.ceil(max(cx,w-cx));height=2*math.ceil(max(cy,h-cy))
    ck=K.clone();ck[0,2]=width/2;ck[1,2]=height/2
    y,x=torch.meshgrid(torch.arange(h,device=K.device)+.5,
                        torch.arange(w,device=K.device)+.5,indexing='ij')
    grid=torch.stack(((x-cx+width/2)/width*2-1,(y-cy+height/2)/height*2-1),-1)
    camera=SimpleNamespace(image_width=width,image_height=height,
        R=sample['viewmat'][:3,:3].T,T=sample['viewmat'][:3,3],Fx=float(K[0,0]),Fy=float(K[1,1]),
        FoVx=2*math.atan(width/(2*float(K[0,0]))),FoVy=2*math.atan(height/(2*float(K[1,1]))),
        world_view_transform=sample['viewmat'].T.contiguous(),
        full_proj_transform=(projection_from_K(ck,width,height)@sample['viewmat']).T.contiguous(),
        camera_center=sample['c2w'][:3,3])
    return camera,grid


def render_geometry(model,sample,render,background=0.,require_depth=True):
    camera,grid=centered_canvas(sample)
    pkg=render(camera,model,SimpleNamespace(debug=False),model.get_xyz.new_full((3,),background),
               kernel_size=0.,require_depth=require_depth)
    def crop(value):
        return F.grid_sample(value[None],grid[None],align_corners=False)[0]
    rgb=crop(pkg['render']).permute(1,2,0)
    alpha=crop(pkg['mask'])[0]
    depth=crop(pkg['median_depth'])[0]
    normal=crop(pkg['normal']).permute(1,2,0)@sample['viewmat'][:3,:3]
    surf=depth_world_normals(sample,depth)*alpha.detach()[...,None]
    return dict(rgb=rgb,alpha=alpha,depth=depth,normal=normal,surface_normal=surf,
                screen=pkg['viewspace_points'],visible=pkg['visibility_filter'],radii=pkg['radii'])


def restore_model(Model,saved):
    model=Model(3,0)
    model.restore(saved['capture'],SimpleNamespace(**saved['config']['optimizer']))
    with torch.no_grad():
        for target,source in [('_xyz','means'),('_scaling','scales'),('_rotation','quats'),('_opacity','opacities')]:
            value=saved['gaussians']['params.'+source]
            if target=='_opacity':value=value[:,None]
            getattr(model,target).copy_(value)
    if saved['config'].get('mip_filter',False):
        model.filter_3D=saved['world_filter_3D']
    else:
        model.reset_3D_filter()
    return model


def restore_evaluation_model(Model,saved):
    """Keep the exact coordinate scale in which continuous depth was optimized."""
    model=Model(3,0)
    model.restore(saved['capture'],SimpleNamespace(**saved['config']['optimizer']))
    if saved['config']['mip_filter']:
        model.filter_3D=saved['world_filter_3D']/saved['config']['training_coordinate_transform']['scale']
    else:
        model.reset_3D_filter()
    return model


def render_evaluation_geometry(model,sample,render,config):
    transform=config['training_coordinate_transform']
    center=sample['viewmat'].new_tensor(transform['center']);scale=transform['scale']
    local=reconstruction_coordinates(sample,center,scale)
    result=render_geometry(model,local,render,config['background'])
    result['depth']=result['depth']*scale
    return result


def prior_losses(result,sample,targets,normal_weight,depth_weight):
    """Reuse camera-Z scale-invariant depth and geometric normal supervision."""
    from surface import surface_losses
    info=dict(surface_depth=result['depth'][...,None],surface_normals=result['normal'],
              surface_distortion=torch.zeros_like(result['depth'][...,None]))
    terms=surface_losses(info,result['alpha'][...,None],sample,targets,1.,
                         normal_weight,depth_weight,0.,0.)
    return {k:v for k,v in terms.items() if k in ('normal_prior','depth_prior')}


def train_geometry(args):
    torch.set_num_threads(8);torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
    Model,opt,render=author_modules()
    opt.iterations=args.steps;opt.position_lr_max_steps=args.steps;opt.densify_until_iter=args.refine_stop
    opt.regularization_from_iter=args.gggs_regularize_from
    out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    data=SceneDataset(args.scene,'train',args.resolution)
    fit,validation=(list(range(len(data))),[]) if args.fit_all else split_train_lights(data.frames)
    priors=None
    if args.surface_priors:
        from surface import SurfacePriors
        priors=SurfacePriors(args.surface_priors,data,fit,
                            need_normal=args.gggs_prior_normal_weight>0,
                            need_depth=args.gggs_prior_depth_weight>0)
    cpu={i:data[i] for i in fit}
    center,radius=camera_bounds(list(cpu.values())[::max(1,len(fit)//32)])
    origins=torch.stack([s['c2w'][:3,3] for s in cpu.values()])
    scale=float(1.1*(origins-origins.mean(0)).norm(dim=-1).max())
    from surface_initialization import prepare_mask_surface
    seeds=prepare_mask_surface(data,fit,validation,args.points,192,2,.95,args.seed,'occupancy')
    xyz=(seeds['positions'].numpy()-center.numpy())/scale
    model=Model(3,0)
    model.create_from_pcd(SimpleNamespace(_xyz=xyz,_rgb=np.full_like(xyz,.5)),1.)
    model.create_app_model(len(fit),Model.App_model.NO)
    model.training_setup(opt)
    samples={i:reconstruction_coordinates(to_device(s,'cuda'),center.cuda(),scale) for i,s in cpu.items()}
    filter_cameras=[centered_canvas(s)[0] for s in samples.values()]
    model.compute_3D_filter(filter_cameras)
    # Preserve the checked-out author's zero percent_dense / GOF population
    # behavior. This setting is reported, not silently changed for comparison.
    config=dict(representation='gggs_core',geometry='3dgs',scene=str(data.scene_path.resolve()),
                resolution=args.resolution,steps=args.steps,seed=args.seed,background=args.background,
                depth_ratio=0.,sh_degree=3,geometry_priors=priors is not None,sdf=False,optimizer=vars(opt),
                surface_priors=args.surface_priors,prior_normal_weight=args.gggs_prior_normal_weight,
                prior_depth_weight=args.gggs_prior_depth_weight,prior_from=args.gggs_prior_from,
                prior_warmup=args.gggs_prior_warmup,
                percent_dense=model.percent_dense,mip_filter=True,mask_weight=args.gggs_mask_weight,
                normal_weight=args.gggs_normal_weight,unit_light_intensity=None,display_gamma=1.,
                training_coordinate_transform=dict(scale=scale,center=center.tolist()),
                upstream_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=UPSTREAM,text=True).strip(),
                scope='Continuous-depth core ablation; not full-paper reproduction',
                differences=['fit-only silhouette seeds instead of SfM','full-K via centered virtual sensor and bilinear output sampling',
                             'foreground alpha loss','no exposure network or multi-view NCC; author 3D Mip filter retained',
                             'normalized training coordinates; exported world coordinates','C++17 build flag for GCC9; CUDA equations unchanged'])
    (out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
    (out/'split.json').write_text(json.dumps(dict(fit=fit,validation=validation),indent=2)+'\n')
    with tarfile.open(out/'upstream_source.tar','w') as archive:
        for p in UPSTREAM.rglob('*'):
            if p.is_file() and p.suffix in ['.py','.h','.cu','.cuh','.cpp','.md'] and not any(k in p.parts for k in ['.git','build','glm']):
                archive.add(p,arcname=str(p.relative_to(UPSTREAM)))
    history=(out/'history.jsonl').open('w',buffering=1);stack=[];start=time.monotonic()
    print(json.dumps(dict(event='initialized_gggs',fit=len(fit),validation=len(validation),points=len(xyz),
                         radius=radius,scale=scale,gpu=torch.cuda.get_device_name())),flush=True)
    for step in range(1,args.steps+1):
        model.update_learning_rate(step)
        if step%1000==0:model.oneupSHdegree()
        if not stack:stack=fit.copy()
        i=stack.pop(random.randrange(len(stack)));sample=samples[i]
        active=step>=args.gggs_regularize_from
        prior_factor=min(1.,max(0.,(step-args.gggs_prior_from+1)/max(1,args.gggs_prior_warmup))) if priors is not None else 0.
        result=render_geometry(model,sample,render,args.background,active or prior_factor>0)
        target=target_image(sample,args.background)
        photo=.8*(result['rgb']-target).abs().mean()+.2*(1-ssim(result['rgb'],target))
        silhouette=args.gggs_mask_weight*(result['alpha']-sample['alpha'][...,0]).abs().mean()
        normal=photo*0
        if active:
            valid=(sample['alpha'][...,0]>.9)&(result['alpha'].detach()>.9)&(result['depth'].detach()>0)
            valid=F.avg_pool2d(valid.float()[None,None],3,1,1)[0,0]==1
            n=F.normalize(result['normal'],dim=-1);dn=F.normalize(result['surface_normal'],dim=-1)
            # Both camera-facing normals; depth cross-product convention matches native adapter.
            normal=args.gggs_normal_weight*((1-(n*dn).sum(-1))*valid).mean()
        terms=dict(photo=photo,normal=normal,silhouette=silhouette)
        if prior_factor:
            terms.update(prior_losses(result,sample,priors.frame(i,'cuda'),
                                      prior_factor*args.gggs_prior_normal_weight,
                                      prior_factor*args.gggs_prior_depth_weight))
        loss=sum(terms.values())
        if not torch.isfinite(loss):raise FloatingPointError(f'gggs loss at {step}')
        loss.backward()
        fields=['_xyz','_scaling','_rotation','_opacity','_features_dc','_features_rest']
        finite=torch.stack([torch.isfinite(getattr(model,key).grad).all() for key in fields])
        if not bool(finite.all()):
            bad=[key for key,good in zip(fields,finite.tolist()) if not good]
            torch.save(dict(config=config,step=step,frame_index=i,capture=model.capture(),
                            filter_3D=model.filter_3D,sample=sample),out/'failed_gradient.pt')
            (out/'failure.json').write_text(json.dumps(dict(step=step,frame_index=i,nonfinite_gradients=bad,
                scales_min=float(model.get_scaling.min()),scales_max=float(model.get_scaling.max())),indent=2)+'\n')
            raise FloatingPointError(f'Nonfinite GGGS gradients at {step}: {bad}')
        with torch.no_grad():
            event=None
            if step<opt.densify_until_iter:
                visible=result['visible']
                model.max_radii2D[visible]=torch.maximum(model.max_radii2D[visible],result['radii'][visible])
                model.add_densification_stats(result['screen'],visible)
                if step>opt.densify_from_iter and step%opt.densification_interval==0:
                    event=model.densify_and_prune(opt.densify_grad_threshold,.05,1.,None)
                    model.compute_3D_filter(filter_cameras)
                if step%opt.opacity_reset_interval==0:model.reset_opacity()
            elif step%100==0 and step<args.steps-100:
                model.compute_3D_filter(filter_cameras)
            if step<args.steps:model.optimizer.step();model.optimizer.zero_grad(set_to_none=True)
            if step==1 or step%100==0 or step==args.steps:
                row=dict(step=step,frame_index=i,loss=float(loss),photo=float(photo),normal=float(normal),
                         silhouette=float(silhouette),points=len(model._xyz),topology_event=event,
                         loss_terms={k:float(v) for k,v in terms.items()},prior_factor=prior_factor,
                         seconds=time.monotonic()-start,memory_GiB=torch.cuda.max_memory_allocated()/2**30)
                history.write(json.dumps(row)+'\n');print(json.dumps(row),flush=True)
    history.close()
    geometry={'center':center.cuda(),'params.means':model._xyz*scale+center.cuda(),
              'params.scales':model._scaling+math.log(scale),'params.quats':model._rotation,
              'params.opacities':model._opacity.squeeze(-1)}
    torch.save(dict(kind='gggs_core',config=config,step=args.steps,capture=model.capture(),gaussians=geometry,
                    world_filter_3D=model.filter_3D*scale,
                    radius=radius,fit_indices=fit,val_indices=validation,camera_offsets=None),out/'last.pt')
    from plot_loss import plot_loss
    plot_loss(out/'history.jsonl')
    print(json.dumps(dict(event='complete',steps=args.steps,seconds=time.monotonic()-start)),flush=True)
