"""Local correction of author 2DGS screen-radius bookkeeping.

Keep upstream source/CUDA intact. Unchanged Gaussians retain observed radii;
exact clones inherit them; displaced split children await new observations.
"""
import torch


def corrected_model_class(author_model):
    class CorrectedNativeModel(author_model):
        _append_radii = None

        def densification_postfix(self, new_xyz, *attributes):
            old_radii = self.max_radii2D
            new_radii = (old_radii.new_zeros(len(new_xyz)) if self._append_radii is None
                         else self._append_radii)
            super().densification_postfix(new_xyz, *attributes)
            self.max_radii2D = torch.cat((old_radii, new_radii))

        def densify_and_clone(self, grads, grad_threshold, scene_extent):
            selected = (grads.norm(dim=-1) >= grad_threshold)
            selected &= self.get_scaling.max(dim=1).values <= self.percent_dense*scene_extent
            self._append_radii = self.max_radii2D[selected]
            super().densify_and_clone(grads, grad_threshold, scene_extent)
            self._append_radii = None

        def densify_and_prune(self, max_grad, min_opacity, extent, max_screen_size):
            before = len(self.get_xyz)
            grads = self.xyz_gradient_accum/self.denom
            grads[grads.isnan()] = 0.
            self.densify_and_clone(grads, max_grad, extent)
            after_clone = len(self.get_xyz)
            # Author split replaces each selected parent with two children.
            self.densify_and_split(grads, max_grad, extent)
            after_split = len(self.get_xyz)
            low_opacity = (self.get_opacity < min_opacity).squeeze(-1)
            screen = torch.zeros_like(low_opacity)
            world = torch.zeros_like(low_opacity)
            if max_screen_size:
                screen = self.max_radii2D > max_screen_size
                world = self.get_scaling.max(dim=1).values > .1*extent
            prune = low_opacity | screen | world
            event = dict(before=before, cloned=after_clone-before,
                         split_parents=after_split-after_clone,
                         split_children=2*(after_split-after_clone),
                         pruned=int(prune.sum()), pruned_opacity=int(low_opacity.sum()),
                         pruned_screen=int(screen.sum()), pruned_world=int(world.sum()))
            self.prune_points(prune)
            event['after'] = len(self.get_xyz)
            # Like the gradient accumulator, radii describe this refinement
            # interval. Clear AFTER the decision, including the early intervals
            # before screen culling activates, so stale large footprints do not
            # delete Gaussians that have since shrunk or moved.
            self.max_radii2D.zero_()
            torch.cuda.empty_cache()
            return event

    return CorrectedNativeModel
