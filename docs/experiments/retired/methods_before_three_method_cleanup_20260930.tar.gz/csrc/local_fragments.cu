#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

// Read-only CSR traversal of the author's GGGS tile lists. No fragment cap.
template<bool WRITE>
__global__ void fragments(const float2* means, const float4* conics,
    const int2* ranges, const int* ids, const int2* xy, int queries,
    int width, int height, int* counts, const int64_t* offsets,
    int64_t* out_gid, int64_t* out_query, float* out_weight) {
    int q=blockIdx.x*blockDim.x+threadIdx.x;
    if(q>=queries)return;
    int2 p=xy[q];int n=0;float T=1.f;
    if(p.x>=0 && p.x<width && p.y>=0 && p.y<height){
        int2 range=ranges[(p.y/16)*((width+15)/16)+p.x/16];
        for(int k=range.x;k<range.y;k++){
            int g=ids[k];float2 m=means[g];float4 c=conics[g];
            float dx=m.x-p.x,dy=m.y-p.y;
            float power=-.5f*(c.x*dx*dx+c.z*dy*dy)-c.y*dx*dy;
            if(power>0.f)continue;
            float a=fminf(.99f,c.w*expf(power));
            if(a<1.f/255.f)continue;
            float next=T*(1.f-a);
            if(next<.0001f)break;
            if(WRITE){int64_t j=offsets[q]+n;out_gid[j]=g;out_query[j]=q;out_weight[j]=a*T;}
            n++;T=next;
        }
    }
    if(!WRITE)counts[q]=n;
}

std::vector<torch::Tensor> gather(torch::Tensor means,torch::Tensor conics,
    torch::Tensor ranges,torch::Tensor ids,torch::Tensor xy,int width,int height){
    c10::cuda::CUDAGuard guard(means.device());
    int q=xy.size(0);auto counts=torch::zeros({q},xy.options());
    auto offsets=torch::zeros({q+1},xy.options().dtype(torch::kInt64));
    auto stream=at::cuda::getCurrentCUDAStream();
    if(q)fragments<false><<<(q+127)/128,128,0,stream>>>(
        (float2*)means.data_ptr<float>(),(float4*)conics.data_ptr<float>(),
        (int2*)ranges.data_ptr<int>(),ids.data_ptr<int>(),(int2*)xy.data_ptr<int>(),
        q,width,height,counts.data_ptr<int>(),nullptr,nullptr,nullptr,nullptr);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    offsets.slice(0,1).copy_(counts.to(torch::kInt64).cumsum(0));
    int64_t n=offsets[q].item<int64_t>();
    auto gid=torch::empty({n},offsets.options()),qid=torch::empty_like(gid);
    auto weight=torch::empty({n},means.options());
    if(q)fragments<true><<<(q+127)/128,128,0,stream>>>(
        (float2*)means.data_ptr<float>(),(float4*)conics.data_ptr<float>(),
        (int2*)ranges.data_ptr<int>(),ids.data_ptr<int>(),(int2*)xy.data_ptr<int>(),
        q,width,height,counts.data_ptr<int>(),offsets.data_ptr<int64_t>(),
        gid.data_ptr<int64_t>(),qid.data_ptr<int64_t>(),weight.data_ptr<float>());
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return {gid,qid,weight,counts};
}
PYBIND11_MODULE(TORCH_EXTENSION_NAME,m){m.def("gather",&gather);}
