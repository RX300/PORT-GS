"""NRHints adapter for the author's unmodified 2DGS model/CUDA rasterizer.

Upstream: https://github.com/hbb1/2d-gaussian-splatting (research license).
The local adapter preserves full K and our pixel-center convention. This stage
fits observed RGB with SH; it has no light-conditioned material or transport.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import math
import random
import subprocess
import sys
import tarfile
import time

import numpy as np
import torch
from torch.nn import functional as F

from data import SceneDataset, split_train_lights
from gaussians import camera_bounds
from evaluate import to_device, target_image, ssim, save_pair

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT / 'third_party/2d-gaussian-splatting'


def author_modules():
    sys.path.insert(0, str(UPSTREAM))
    sys.path.insert(0, str(UPSTREAM/'submodules/diff-surfel-rasterization'))
    sys.path.insert(0, str(UPSTREAM/'submodules/simple-knn'))
    # Load the author model directly: upstream scene.__init__ would import
    # unrelated dataset/mesh dependencies. The model file itself is unchanged.
    spec = importlib.util.spec_from_file_location('port_author_gaussian', UPSTREAM/'scene/gaussian_model.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    from arguments import OptimizationParams
    parser = argparse.ArgumentParser()
    options = OptimizationParams(parser).extract(parser.parse_args([]))
    from diff_surfel_rasterization import GaussianRasterizationSettings, GaussianRasterizer
    return module.GaussianModel, options, GaussianRasterizationSettings, GaussianRasterizer


def projection_from_K(K, width, height, near=.01, far=100.):
    """Native ndc2pix maps to integer indices; K describes i+.5 pixel centers."""
    p = K.new_zeros((4, 4))
    p[0, 0], p[1, 1] = 2*K[0, 0]/width, 2*K[1, 1]/height
    p[0, 2], p[1, 2] = 2*K[0, 2]/width-1, 2*K[1, 2]/height-1
    p[2, 2], p[2, 3], p[3, 2] = far/(far-near), -far*near/(far-near), 1
    return p


def depth_points(sample, depth):
    h, w = depth.shape
    y, x = torch.meshgrid(torch.arange(h, device=depth.device)+.5,
                          torch.arange(w, device=depth.device)+.5, indexing='ij')
    ray = torch.stack((x, y, torch.ones_like(x)), -1) @ torch.linalg.inv(sample['K']).T
    camera = ray*depth[..., None]
    view = sample['viewmat']
    return (camera-view[:3, 3]) @ view[:3, :3]


def depth_world_normals(sample, depth):
    xyz = depth_points(sample, depth)
    dy = xyz[2:, 1:-1]-xyz[:-2, 1:-1]
    dx = xyz[1:-1, 2:]-xyz[1:-1, :-2]
    n = F.normalize(torch.linalg.cross(dy, dx), dim=-1)
    return F.pad(n.permute(2, 0, 1), (1, 1, 1, 1)).permute(1, 2, 0)


def reconstruction_coordinates(sample, center, scale):
    """Apply x_world = scale*x_local + center without changing image rays."""
    sample=dict(sample)
    view=sample['viewmat'].clone()
    view[:3,3]=(view[:3,:3]@center+view[:3,3])/scale
    sample['viewmat']=view
    pose=sample['c2w'].clone();pose[:3,3]=(pose[:3,3]-center)/scale
    sample['c2w']=pose
    return sample


def restore_native_model(Model, saved):
    """Restore appearance, and use the exported WORLD geometry for evaluation.

    The author optimizer capture stays in its documented training coordinates.
    This inference helper does not resume that optimizer after conversion.
    """
    model=Model(saved['config']['sh_degree'])
    model.restore(saved['capture'],SimpleNamespace(**saved['config']['optimizer']))
    with torch.no_grad():
        for target,source in [('_xyz','means'),('_scaling','scales'),
                              ('_rotation','quats'),('_opacity','opacities')]:
            value=saved['gaussians']['params.'+source]
            if target=='_opacity':value=value[:,None]
            getattr(model,target).copy_(value)
    return model


def render_native(model, sample, settings_class, raster_class, depth_ratio=1., background=0.):
    h, w = sample['image'].shape[:2]
    K, view = sample['K'], sample['viewmat']
    projection = projection_from_K(K, w, h)
    settings = settings_class(image_height=h, image_width=w,
        tanfovx=float(w/(2*K[0, 0])), tanfovy=float(h/(2*K[1, 1])),
        bg=model.get_xyz.new_full((3,), background), scale_modifier=1.,
        viewmatrix=view.T.contiguous(), projmatrix=(projection@view).T.contiguous(),
        sh_degree=model.active_sh_degree, campos=sample['c2w'][:3, 3],
        prefiltered=False, debug=False)
    screen = torch.zeros_like(model.get_xyz, requires_grad=True)+0
    if torch.is_grad_enabled():
        screen.retain_grad()
    rgb, radii, maps = raster_class(raster_settings=settings)(
        means3D=model.get_xyz, means2D=screen, shs=model.get_features,
        colors_precomp=None, opacities=model.get_opacity, scales=model.get_scaling,
        rotations=model.get_rotation, cov3D_precomp=None)
    alpha = maps[1]
    normal = maps[2:5].permute(1, 2, 0) @ view[:3, :3]
    expected = torch.nan_to_num(maps[0]/alpha, nan=0., posinf=0., neginf=0.)
    median = torch.nan_to_num(maps[5], nan=0., posinf=0., neginf=0.)
    depth = (1-depth_ratio)*expected + depth_ratio*median
    surface_normal = depth_world_normals(sample, depth)*alpha.detach()[..., None]
    return {'rgb': rgb.permute(1, 2, 0), 'alpha': alpha, 'normal': normal,
            'depth': depth, 'surface_normal': surface_normal, 'distortion': maps[6],
            'screen': screen, 'visible': radii > 0, 'radii': radii}


def upstream_record():
    return {'repository':'https://github.com/hbb1/2d-gaussian-splatting',
        'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=UPSTREAM,text=True).strip(),
        'rasterizer_revision':subprocess.check_output(['git','rev-parse','HEAD'],
             cwd=UPSTREAM/'submodules/diff-surfel-rasterization',text=True).strip(),
        'model_and_cuda_unmodified':True,
        'adapter_differences':['NRHints full intrinsics including off-center principal point',
          'depth normals use the same i+.5 pixel centers as the camera adapter',
          'train-only mask occupancy initialization (if selected); no supplied points3d.ply',
          'checkpoint/export and evaluation protocols; no viewer/network GUI'],
        'appearance':'observed RGB SH3, view dependent; moving lights are not disentangled'}


def train_native(args):
    torch.set_num_threads(8)
    torch.manual_seed(args.seed); np.random.seed(args.seed); random.seed(args.seed)
    if args.native_init not in ('mask', 'random'):
        raise ValueError('native-init must be mask or random')
    if args.native_mask_weight < 0:
        raise ValueError('native-mask-weight must be nonnegative')
    if args.native_coordinate_scale not in ('world','camera_extent'):
        raise ValueError('native-coordinate-scale must be world or camera_extent')
    if args.native_topology not in ('author','corrected') or args.native_split_extent not in ('camera','object'):
        raise ValueError('Expected native-topology author/corrected and native-split-extent camera/object')
    Model, opt, Settings, Rasterizer = author_modules()
    if args.native_topology == 'corrected':
        from native_topology import corrected_model_class
        Model = corrected_model_class(Model)
    opt.iterations = args.steps
    opt.position_lr_max_steps = args.lr_decay_steps or args.steps
    opt.lambda_normal, opt.lambda_dist = args.native_normal_weight, args.native_distortion_weight
    opt.densify_until_iter = args.refine_stop
    out = Path(args.output); out.mkdir(parents=True, exist_ok=False)
    data = SceneDataset(args.scene, 'train', args.resolution)
    fit, validation = (list(range(len(data))), []) if args.fit_all else split_train_lights(data.frames)
    center, radius = camera_bounds([data[i] for i in fit[::max(1,len(fit)//32)]])
    config = dict(representation='native_2dgs', geometry='2dgs', scene=str(data.scene_path.resolve()),
        resolution=args.resolution, steps=args.steps, seed=args.seed, background=args.background,
        sh_degree=args.native_sh_degree, depth_ratio=args.native_depth_ratio, init=args.native_init,
        points=args.points, fit_all=args.fit_all, unit_light_intensity=None, display_gamma=1.,
        mask_weight=args.native_mask_weight,
        coordinate_scale=args.native_coordinate_scale,
        topology=args.native_topology, split_extent=args.native_split_extent,
        optimizer=vars(opt), upstream=upstream_record(), geometry_priors=False, sdf=False)
    if args.native_mask_weight:
        config['upstream']['adapter_differences'].append(
            'Explicit supplied-alpha L1 supervision; native model/CUDA unchanged')
    if args.native_topology == 'corrected':
        config['upstream']['adapter_differences'].append(
            'Project topology subclass preserves screen-radius history, including exact clones; upstream files unchanged')
    (out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
    (out/'split.json').write_text(json.dumps({'fit':fit,'validation':validation},indent=2)+'\n')
    with tarfile.open(out/'upstream_source.tar','w') as archive:
        for path in UPSTREAM.rglob('*'):
            if path.is_file() and path.suffix in ('.py','.cu','.cuh','.cpp','.h','.md') and not any(
                    part in ('.git','build','third_party') for part in path.relative_to(UPSTREAM).parts):
                archive.add(path,arcname=str(path.relative_to(UPSTREAM)))
    if args.native_init == 'mask':
        from surface_initialization import prepare_mask_surface
        seeds = prepare_mask_surface(data,fit,validation,args.points,192,2,.95,args.seed,'occupancy')
        xyz = seeds['positions'].numpy()
        (out/'initialization.json').write_text(json.dumps({
            'construction':seeds['construction'],'sampling':seeds['sampling'],
            'fit_indices':fit,'validation_indices':validation,
            'note':'Only point positions supplied; author kNN scales/random rotations retained'},indent=2)+'\n')
    else:
        xyz = (np.random.random((args.points,3))*2-1)*radius+center.numpy()
    model = Model(args.native_sh_degree)
    # Author model ignores point-cloud normals, initializes SH DC from color,
    # kNN tangent scales, random rotations and opacity .1.
    samples = {i:to_device(data[i],'cuda') for i in fit}
    origins = torch.stack([samples[i]['c2w'][:3,3] for i in fit])
    extent = float(1.1*(origins-origins.mean(0)).norm(dim=-1).max())
    if args.native_split_extent == 'object':
        opt.percent_dense *= radius/extent
        config['upstream']['adapter_differences'].append(
            'Split size threshold uses object camera-bound radius; position LR and world pruning still use camera extent')
    coordinate_scale=extent if args.native_coordinate_scale=='camera_extent' else 1.
    coordinate_center=center.cuda() if args.native_coordinate_scale=='camera_extent' else center.new_zeros(3).cuda()
    config['training_coordinate_transform']={'world_equals_scale_times_local_plus_center':True,
        'scale':coordinate_scale,'center':coordinate_center.tolist()}
    if args.native_coordinate_scale=='camera_extent':
        xyz=(xyz-coordinate_center.cpu().numpy())/coordinate_scale
        samples={i:reconstruction_coordinates(s,coordinate_center,coordinate_scale) for i,s in samples.items()}
        config['upstream']['adapter_differences'].append(
            'Train in camera-extent-normalized coordinates; export geometry in original world coordinates')
    (out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
    model.create_from_pcd(SimpleNamespace(points=xyz, colors=np.full_like(xyz,.5),
                                        normals=np.zeros_like(xyz)), extent/coordinate_scale)
    model.training_setup(opt)
    history = (out/'history.jsonl').open('w',buffering=1)
    print(json.dumps({'event':'initialized_native_2dgs','fit':len(fit),'validation':len(validation),
        'points':len(xyz),'camera_extent':extent,'radius':radius,
        'coordinate_scale':coordinate_scale,
        'gpu':torch.cuda.get_device_name(),'config':str(out/'config.json')}),flush=True)
    start = time.monotonic(); stack = []
    topology_totals = dict(cloned=0, split_parents=0, split_children=0,
                           pruned=0, pruned_opacity=0, pruned_screen=0, pruned_world=0)
    for step in range(1,args.steps+1):
        model.update_learning_rate(step)
        if step % 1000 == 0: model.oneupSHdegree()
        if not stack: stack = fit.copy()
        index = stack.pop(random.randrange(len(stack)))
        sample = samples[index]
        result = render_native(model,sample,Settings,Rasterizer,args.native_depth_ratio,args.background)
        target = target_image(sample,args.background)
        l1 = (result['rgb']-target).abs().mean()
        photo = .8*l1+.2*(1-ssim(result['rgb'],target))
        normal = (opt.lambda_normal if step>7000 else 0.)*(1-(result['normal']*result['surface_normal']).sum(-1)).mean()
        distortion = (opt.lambda_dist if step>3000 else 0.)*result['distortion'].mean()
        silhouette = args.native_mask_weight*(result['alpha']-sample['alpha'][...,0]).abs().mean()
        loss = photo+normal+distortion+silhouette
        if not torch.isfinite(loss): raise FloatingPointError(f'native_2dgs loss at {step}')
        loss.backward()
        topology_event = None
        with torch.no_grad():
            if step < opt.densify_until_iter:
                visible = result['visible']
                model.max_radii2D[visible] = torch.maximum(model.max_radii2D[visible],result['radii'][visible])
                model.add_densification_stats(result['screen'],visible)
                if step>opt.densify_from_iter and step % opt.densification_interval==0:
                    topology_event = model.densify_and_prune(
                        opt.densify_grad_threshold,opt.opacity_cull,extent/coordinate_scale,
                        20 if step>opt.opacity_reset_interval else None)
                    if topology_event:
                        for key in topology_totals:topology_totals[key] += topology_event[key]
                if step % opt.opacity_reset_interval==0:
                    model.reset_opacity()
            if step < args.steps:
                model.optimizer.step(); model.optimizer.zero_grad(set_to_none=True)
            if step==1 or step%100==0 or step==args.steps:
                opacity=model.get_opacity.flatten()
                row={'step':step,'frame_index':index,'loss':float(loss),'l1':float(l1),
                    'photo':float(photo),'normal':float(normal),'distortion':float(distortion),
                    'silhouette':float(silhouette),
                    'loss_terms':{'photo':float(photo),'normal':float(normal),
                                  'distortion':float(distortion),'silhouette':float(silhouette)},
                    'points':len(opacity),'opacity_eligible':int((opacity>=1/255).sum()),
                    'sh_degree':model.active_sh_degree,'seconds':time.monotonic()-start,
                    'topology_event':topology_event, 'topology_totals':dict(topology_totals),
                    'memory_GiB':torch.cuda.max_memory_allocated()/2**30}
                history.write(json.dumps(row)+'\n');print(json.dumps(row),flush=True)
    history.close()
    # Canonical geometry-only transfer payload is compatible with --init-geometry.
    geometry={'center':center.cuda(),'params.means':model._xyz*coordinate_scale+coordinate_center,
              'params.scales':model._scaling+math.log(coordinate_scale),
              'params.quats':model._rotation,'params.opacities':model._opacity.squeeze(-1)}
    torch.save({'kind':'native_2dgs','config':config,'step':args.steps,'capture':model.capture(),
                'gaussians':geometry,'radius':radius,'fit_indices':fit,'val_indices':validation,
                'camera_offsets':None,'topology_totals':topology_totals},out/'last.pt')
    with torch.no_grad():
        model._xyz.copy_(geometry['params.means']);model._scaling.copy_(geometry['params.scales'])
    model.save_ply(str(out/'surfels.ply'))
    from plot_loss import plot_loss
    plot_loss(out/'history.jsonl')
    print(json.dumps({'event':'complete','steps':args.steps,'seconds':time.monotonic()-start}),flush=True)


def geometry_metrics(result, sample, radius):
    alpha, depth = result['alpha'], result['depth']
    target = sample['alpha'][...,0]>.9
    mask = alpha>.5
    iou = (mask&target).sum().float()/(mask|target).sum().clamp_min(1)
    interior = F.avg_pool2d(((alpha>.9)&target&(depth>0)).float()[None,None],3,1,1)[0,0]==1
    a,b=F.normalize(result['normal'],dim=-1),F.normalize(result['surface_normal'],dim=-1)
    angular=(1-(a*b).sum(-1).clamp(-1,1))[interior]
    return {'silhouette_IoU':float(iou),'alpha_L1':float((alpha-sample['alpha'][...,0]).abs().mean()),
        'self_normal_angular_error':float(angular.mean()) if len(angular) else None,
        'valid_surface_fraction':float(interior.float().mean()),**boundary_metrics(result,sample)}


def boundary_metrics(result,sample):
    """Silhouette agreement and boundary depth-normal roughness, not GT shape."""
    import cv2
    gt=(sample['alpha'][...,0]>.9).cpu().numpy().astype(np.uint8)
    pred=(result['alpha']>.5).cpu().numpy().astype(np.uint8)
    kernel=np.ones((3,3),np.uint8)
    gb=gt-cv2.erode(gt,kernel);pb=pred-cv2.erode(pred,kernel)
    dg=cv2.distanceTransform(1-gb,cv2.DIST_L2,cv2.DIST_MASK_PRECISE)
    dp=cv2.distanceTransform(1-pb,cv2.DIST_L2,cv2.DIST_MASK_PRECISE)
    outside=cv2.distanceTransform(1-gt,cv2.DIST_L2,cv2.DIST_MASK_PRECISE)
    distance=outside[pb.astype(bool)]
    precision=float((dg[pb.astype(bool)]<=2).mean()) if pb.any() else 0.
    recall=float((dp[gb.astype(bool)]<=2).mean()) if gb.any() else 0.
    n=F.normalize(result['surface_normal'],dim=-1)
    band=torch.from_numpy((dg<=8)&(gt>0)).to(n.device)
    valid=band&(result['alpha']>.9)&(result['depth']>0)
    values=[]
    for axis in [0,1]:
        other=n.roll(1,axis);both=valid&valid.roll(1,axis)
        both[0,:]=False;both[:,0]=False
        angle=(n*other).sum(-1).clamp(-1,1).acos()*180/math.pi
        values.append(angle[both])
    values=torch.cat(values)
    return dict(boundary_F1_2px=2*precision*recall/max(precision+recall,1e-8),
        boundary_precision_2px=precision,boundary_recall_2px=recall,
        boundary_outward_fraction_over_2px=float((distance>2).mean()) if len(distance) else 0.,
        boundary_outward_p95_px=float(np.quantile(distance,.95)) if len(distance) else None,
        boundary_depth_normal_roughness_p95_deg=float(torch.quantile(values,.95)) if len(values) else None)


def save_geometry_panel(path, frames):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(len(frames),5,figsize=(15,3*len(frames)),squeeze=False)
    labels=['GT RGB','SH reconstruction','Geometry normals','Surface depth','Geometry-only clay']
    for row,(index,target,result) in enumerate(frames):
        alpha=result['alpha'];normal=F.normalize(result['normal'],dim=-1)
        mask=alpha>.5;depth=result['depth'].clone()
        valid=depth[mask&(depth>0)]
        if len(valid):
            lo,hi=torch.quantile(valid,torch.tensor([.02,.98]))
            depth=((depth-lo)/(hi-lo).clamp_min(1e-6)).clamp(0,1)*mask
        else:
            depth.zero_()
        # Fixed world direction. SH, fitted color, and captured lights are absent.
        direction=F.normalize(torch.tensor([.4,-.5,.8]),dim=0)
        gray=(.2+.8*(normal*direction).sum(-1).abs())*alpha
        images=[target,result['rgb'].clamp(0,1),(normal*.5+.5)*alpha[...,None],depth,gray]
        for col,img in enumerate(images):
            axes[row,col].imshow(img.numpy(),cmap='gray' if col>=3 else None,vmin=0,vmax=1)
            axes[row,col].set_title(f'{labels[col]} | {index}');axes[row,col].axis('off')
    fig.tight_layout();fig.savefig(path,dpi=130);plt.close(fig)


def write_surface_points(path, samples, results, center, radius):
    from plyfile import PlyData,PlyElement
    points=[]; normals=[]
    for sample,result in zip(samples,results):
        mask=(result['alpha']>.9)&(sample['alpha'][...,0]>.9)&(result['depth']>0)
        xyz=depth_points(sample,result['depth']);n=F.normalize(result['normal'],dim=-1)
        mask &= (xyz-center.to(xyz)).norm(dim=-1)<2*radius
        ids=torch.nonzero(mask.reshape(-1)).flatten()[::4]
        points.append(xyz.reshape(-1,3)[ids].numpy());normals.append(n.reshape(-1,3)[ids].numpy())
    p,n=np.concatenate(points),np.concatenate(normals)
    vertices=np.empty(len(p),dtype=[(k,'f4') for k in ['x','y','z','nx','ny','nz']])
    for i,k in enumerate(vertices.dtype.names):vertices[k]=np.concatenate((p,n),axis=-1)[:,i]
    PlyData([PlyElement.describe(vertices,'vertex')]).write(str(path))


def depth_reprojection(source, source_result, target, target_result, radius):
    """Prediction-to-prediction consistency; not an independent geometry error."""
    xyz=depth_points(source,source_result['depth']).reshape(-1,3)
    cam=xyz@target['viewmat'][:3,:3].T+target['viewmat'][:3,3]
    homogeneous=cam@target['K'].T
    uv=homogeneous[:,:2]/homogeneous[:,2:].clamp_min(1e-8)
    h,w=target_result['depth'].shape
    grid=(uv/uv.new_tensor([w,h])*2-1).reshape(1,1,-1,2)
    fields=torch.stack((target_result['depth'],target_result['alpha'],target['alpha'][...,0]))
    queried=F.grid_sample(fields[None],grid,align_corners=False)[0,:,0].T
    valid=(source_result['alpha'].flatten()>.9)&(source['alpha'][...,0].flatten()>.9)
    valid &= (cam[:,2]>.01)&(uv[:,0]>=.5)&(uv[:,0]<=w-.5)&(uv[:,1]>=.5)&(uv[:,1]<=h-.5)
    valid &= (queried[:,0]>0)&(queried[:,1]>.9)&(queried[:,2]>.9)
    residual=(cam[:,2]-queried[:,0])/radius
    values=residual[valid];unoccluded=values<=.01;errors=values[unoccluded].abs()
    return {'candidate_pixels':int(valid.sum()),'occluded_fraction':float((~unoccluded).float().mean()) if len(values) else None,
        'agreement_1pct_radius_before_occlusion_filter':float((values.abs()<.01).float().mean()) if len(values) else None,
        'nonoccluded_pixels':len(errors),'median_abs_depth_over_radius':float(errors.median()) if len(errors) else None,
        'p90_abs_depth_over_radius':float(torch.quantile(errors,.9)) if len(errors) else None}


@torch.no_grad()
def evaluate_native(args):
    grounded=getattr(args,'gggs',False)
    wrapping=getattr(args,'wrapping',False)
    if wrapping:
        from wrapping_reconstruction import author_modules as wrapping_modules, restore_model, render_geometry
        Model,opt,backend=wrapping_modules()
        render_model=lambda model,sample:render_geometry(model,sample,backend,cfg['background'])
    elif grounded:
        from gggs_reconstruction import (author_modules as grounded_modules,
            restore_evaluation_model as restore_model,render_evaluation_geometry)
        Model,opt,backend=grounded_modules()
        render_model=lambda model,sample:render_evaluation_geometry(model,sample,backend,cfg)
    else:
        Model,opt,Settings,Rasterizer=author_modules()
        restore_model=restore_native_model
        render_model=lambda model,sample:render_native(model,sample,Settings,Rasterizer,cfg['depth_ratio'],cfg['background'])
    saved=torch.load(args.checkpoint,map_location='cuda',weights_only=False)
    expected='gaussian_wrapping' if wrapping else 'gggs_core' if grounded else 'native_2dgs'
    if saved['kind']!=expected:raise ValueError('Wrong reconstruction backend')
    cfg=saved['config'];model=restore_model(Model,saved)
    resolution=args.resolution or cfg['resolution']
    dataset=SceneDataset(cfg['scene'],'train' if args.split in ['fit','validation'] else args.split,resolution)
    indices=saved['fit_indices'] if args.split=='fit' else saved['val_indices'] if args.split=='validation' else list(range(len(dataset)))
    if args.limit:indices=indices[::max(1,len(indices)//args.limit)][:args.limit]
    if not indices:raise ValueError('Empty reconstruction evaluation split')
    output=Path(args.output);output.mkdir(parents=True,exist_ok=False)
    lpips_model=None
    if args.lpips:
        import lpips
        lpips_model=lpips.LPIPS(net='vgg').cuda().eval()
    chosen={indices[i] for i in np.linspace(0,len(indices)-1,min(4,len(indices)),dtype=int)}
    rows=[];frames=[];point_samples=[];point_results=[]
    for ordinal,index in enumerate(indices):
        sample=to_device(dataset[index],'cuda')
        result=render_model(model,sample)
        target=target_image(sample,cfg['background']).clamp(0,1);pred=result['rgb'].clamp(0,1)
        x,y=(pred*255).round()/255,(target*255).round()/255
        row={'frame_index':index,'name':sample['name'],
             'PSNR':float(-10*torch.log10((x-y).square().mean())),
             'SSIM':float(ssim(x,y)),**geometry_metrics(result,sample,saved['radius'])}
        if lpips_model is not None:row['LPIPS']=float(lpips_model(x.permute(2,0,1)[None]*2-1,y.permute(2,0,1)[None]*2-1))
        rows.append(row)
        if args.save_all or ordinal<4:save_pair(output/f'pair_{ordinal:03}.png',x,y)
        if index in chosen:
            cpu={k:result[k].cpu() for k in ['rgb','alpha','depth','normal','surface_normal']}
            frames.append((index,target.cpu(),cpu));point_results.append(cpu)
            point_samples.append({k:v.cpu() if isinstance(v,torch.Tensor) else v for k,v in sample.items()})
        if ordinal%50==0:print(json.dumps({'evaluated':ordinal+1,'total':len(indices)}),flush=True)
    metrics={k:sum(row[k] for row in rows if row[k] is not None)/sum(row[k] is not None for row in rows)
             for k in rows[0] if k not in ('frame_index','name') and any(row[k] is not None for row in rows)}
    report={'checkpoint':str(Path(args.checkpoint).resolve()),'split':args.split,'evaluated_frames':len(rows),
        'metrics':metrics,'views':rows,'geometry_scope':'Silhouette and self consistency, no reference geometry. RGB under moving lights is not relighting quality.',
        'camera_protocol':'original full intrinsics/extrinsics; no pose fitting','selected_geometry_frames':sorted(chosen)}
    report['render_coordinate_protocol']='training-normalized GGGS solver, depth returned in world units' if grounded else 'world-coordinate renderer'
    (output/'metrics.json').write_text(json.dumps(report,indent=2)+'\n')
    save_geometry_panel(output/'geometry_panel.png',frames)
    write_surface_points(output/'surface_points.ply',point_samples,point_results,saved['gaussians']['center'].cpu(),saved['radius'])
    train_data=SceneDataset(cfg['scene'],'train',resolution)
    poses=torch.tensor([train_data.frames[i]['transform_matrix'] for i in saved['fit_indices']])
    center=saved['gaussians']['center'].cpu()
    directions=F.normalize(poses[:,:3,3]-center,dim=-1)
    checks=[]
    for source,source_result in zip(point_samples,point_results):
        direction=F.normalize(source['c2w'][:3,3]-center,dim=0)
        cosine=directions@direction
        for index in torch.argsort(cosine,descending=True).tolist():
            neighbor_index=saved['fit_indices'][index]
            if args.split not in ('fit','train') or neighbor_index!=source['frame_index']:
                break
        neighbor=to_device(train_data[neighbor_index],'cuda')
        nr=render_model(model,neighbor)
        nc={k:v.cpu() if isinstance(v,torch.Tensor) else v for k,v in neighbor.items()}
        nr={k:nr[k].cpu() for k in ('alpha','depth')}
        checks.append({'source_index':source['frame_index'],'target_fit_index':neighbor_index,
            'center_view_angle_degrees':float(torch.acos(cosine[index].clamp(-1,1))*180/torch.pi),
            'forward':depth_reprojection(source,source_result,nc,nr,saved['radius']),
            'reverse':depth_reprojection(nc,nr,source,source_result,saved['radius'])})
    (output/'geometry_consistency.json').write_text(json.dumps({'scope':'Four fixed views vs nearest fit camera. Self consistency only; occlusion-filter rejection is reported.',
        'pairs':checks},indent=2)+'\n')
    torch.save({'frames':[(i,{k:v for k,v in result.items() if k!='rgb'}) for i,_,result in frames],
                'scope':'Four fixed camera geometry buffers for review; no GT depth'},output/'geometry_views.pt')
    print(json.dumps(metrics),flush=True)
