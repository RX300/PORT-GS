"""Fit-mask surface seeds, not geometry truth or a continuing shape constraint.

CPU only: silhouette-consensus carving, smoothed signed-distance zero crossings,
area-weighted sampling and tangent jitter projected back onto that field. The
Gaussian optimizer subsequently owns independent positions/scales/orientations.
"""

import math

import cv2
import numpy as np
import torch
from scipy.ndimage import distance_transform_edt, gaussian_filter, map_coordinates

from gaussians import camera_bounds


def carve_mask_consensus(cameras, center, radius, side, consensus):
    """Camera entries are (viewmat,K,dilated_mask), all CPU arrays.

    Voxel nodes are indexed[x,y,z]. Early removal after too many silhouette
    misses is exact for the declared vote threshold; it does not approximate
    that threshold by a subset of cameras. Invalid/behind-camera nodes miss.
    """
    if side < 4 or radius <= 0 or not cameras or not 0 < consensus <= 1:
        raise ValueError('Invalid mask-consensus volume specification')
    spacing = 2*radius/(side-1)
    origin = np.asarray(center, dtype=np.float64)-radius
    active = np.arange(side**3, dtype=np.int64)
    misses = np.zeros(side**3, dtype=np.int32)
    allowed_misses = len(cameras)-math.ceil(consensus*len(cameras))
    for view, K, mask in cameras:
        # Bound temporary CPU memory even for the first full-volume cameras.
        for start in range(0, len(active), 262144):
            ids = active[start:start+262144]
            ijk = np.stack((ids//(side*side), ids//side % side, ids % side), -1)
            world = origin+spacing*ijk
            camera = world @ view[:3, :3].T+view[:3, 3]
            homogeneous = camera @ K.T
            front = camera[:, 2] > .01
            xy = np.zeros((len(ids), 2), dtype=np.float64)
            xy[front] = homogeneous[front, :2]/homogeneous[front, 2:]
            height, width = mask.shape
            valid = front & (xy[:, 0] >= 0) & (xy[:, 0] < width) & (xy[:, 1] >= 0) & (xy[:, 1] < height)
            hit = np.zeros(len(ids), dtype=bool)
            pixels = np.floor(xy[valid]).astype(np.int64)
            hit[valid] = mask[pixels[:, 1], pixels[:, 0]]
            misses[ids] += ~hit
        active = active[misses[active] <= allowed_misses]
    occupied = np.zeros(side**3, dtype=bool)
    occupied[active] = True
    occupied = occupied.reshape((side, side, side))
    if not occupied.any():
        raise ValueError('Training-mask consensus volume is empty')
    if any((np.take(occupied, 0, axis=a).any() or np.take(occupied, -1, axis=a).any()) for a in range(3)):
        raise ValueError('Training-mask volume touches the construction box boundary')
    return occupied, origin, spacing


def normals_to_quaternions(normals):
    """wxyz rotations taking local +Z to each world normal, stable near -Z."""
    normals = np.asarray(normals, dtype=np.float64)
    normals = normals/np.linalg.norm(normals, axis=-1, keepdims=True)
    transverse = np.linalg.norm(normals[:, :2], axis=-1)
    angle = np.arctan2(transverse, normals[:, 2])
    axis = np.stack((-normals[:, 1], normals[:, 0], np.zeros(len(normals))), -1)
    nonzero = transverse > 0
    axis[nonzero] /= transverse[nonzero, None]
    axis[~nonzero] = [1., 0., 0.]
    return np.concatenate((np.cos(angle[:, None]*.5), axis*np.sin(angle[:, None]*.5)), -1)


def sample_zero_surface(field, origin, spacing, count, seed):
    """Approximate area sampling of a regular-grid zero set, in world units.

    Axis-a edge crossings have local density |n_a|/h^2 per surface area.
    Giving them weight h^2|n_a| sums to unit area density over the three axes
    for a plane. Curved-grid area and sampling remain approximations.
    """
    field = np.asarray(field, dtype=np.float64)
    gradient = np.stack(np.gradient(field, spacing), axis=0)
    points, area_weights = [], []
    for axis in range(3):
        lo, hi = [slice(None)]*3, [slice(None)]*3
        lo[axis], hi[axis] = slice(None, -1), slice(1, None)
        left, right = field[tuple(lo)], field[tuple(hi)]
        crossing = (left < 0) != (right < 0)
        indices = np.argwhere(crossing).astype(np.float64)
        indices[:, axis] += left[crossing]/(left[crossing]-right[crossing])
        grad = np.stack([map_coordinates(g, indices.T, order=1, mode='nearest', prefilter=False)
                         for g in gradient], -1)
        normal = grad/np.linalg.norm(grad, axis=-1, keepdims=True)
        points.append(indices)
        area_weights.append(spacing**2*np.abs(normal[:, axis]))
    grid_points = np.concatenate(points)
    weights = np.concatenate(area_weights)
    area = weights.sum()
    if count <= 0 or not np.isfinite(area) or area <= 0:
        raise ValueError('Surface sampling needs positive count and finite nonzero surface area')
    rng = np.random.default_rng(seed)
    selected = rng.choice(len(grid_points), size=count, replace=True, p=weights/area)
    coords = grid_points[selected].copy()
    grad = np.stack([map_coordinates(g, coords.T, order=1, mode='nearest', prefilter=False)
                     for g in gradient], -1)
    normal = grad/np.linalg.norm(grad, axis=-1, keepdims=True)
    reference = np.eye(3)[np.abs(normal).argmin(-1)]
    u = np.cross(reference, normal); u /= np.linalg.norm(u, axis=-1, keepdims=True)
    v = np.cross(normal, u)
    jitter = rng.uniform(-.45, .45, (count, 2))
    coords += u*jitter[:, :1]+v*jitter[:, 1:]
    for _ in range(6):
        value = map_coordinates(field, coords.T, order=1, mode='nearest', prefilter=False)
        grad = np.stack([map_coordinates(g, coords.T, order=1, mode='nearest', prefilter=False)
                         for g in gradient], -1)
        coords -= value[:, None]*grad/(spacing*np.square(grad).sum(-1, keepdims=True))
    residual = map_coordinates(field, coords.T, order=1, mode='nearest', prefilter=False)
    grad = np.stack([map_coordinates(g, coords.T, order=1, mode='nearest', prefilter=False)
                     for g in gradient], -1)
    normals = grad/np.linalg.norm(grad, axis=-1, keepdims=True)
    if (not np.isfinite(coords).all() or not np.isfinite(normals).all() or
            (coords < 0).any() or (coords > np.array(field.shape)-1).any() or
            np.max(np.abs(residual)) > .05*spacing):
        raise ValueError('Jittered surface seeds did not project inside the field with residual <= .05 voxel')
    positions = np.asarray(origin)+coords*spacing
    # With the unchanged initial opacity~.1, sigma=2*sqrt(area/N) gives
    # plane-average optical thickness~2.5 for a uniform sample. Curvature,
    # finite disks, random overlaps and self-occlusion change actual coverage.
    sigma = 2*math.sqrt(area/count)
    return {'positions': torch.from_numpy(positions).float(),
            'normals': torch.from_numpy(normals).float(),
            'quats': torch.from_numpy(normals_to_quaternions(normals)).float(),
            'scales': torch.full((count, 2), sigma),
            'sampling': {'edge_crossings': len(grid_points), 'area_estimate': float(area),
                         'tangent_sigma': sigma, 'max_projection_residual_voxels': float(np.abs(residual).max()/spacing),
                         'jitter_half_width_voxels': .45, 'projection_iterations': 6}}


def sample_occupancy_surface(occupied, origin, spacing, count, seed):
    """Sample an occupancy isosurface directly, without any distance field."""
    density = gaussian_filter(occupied.astype(np.float64), sigma=.75)
    # This scalar is occupancy minus a threshold, not a signed distance. Reuse
    # the edge-crossing sampler/Newton projection on this generic scalar field.
    seeds = sample_zero_surface((.5-density)*spacing, origin, spacing, count, seed)
    seeds['sampling'].update(surface='smoothed_occupancy_isosurface', level=.5,
                             distance_field=False)
    return seeds



def prepare_mask_surface(dataset, fit_indices, val_indices, count=100000,
                         grid_size=192, padding=2, consensus=.95, seed=0,
                         surface_mode='distance'):
    """Use every declared fit silhouette and no held-out image or learned model."""
    if set(fit_indices) & set(val_indices) or not fit_indices or padding < 0:
        raise ValueError('Initialization requires disjoint nonempty fit indices and nonnegative mask padding')
    bound_indices = fit_indices[::max(1, len(fit_indices)//32)]
    center, radius = camera_bounds([dataset[i] for i in bound_indices])
    center = center.cpu().numpy()
    cameras = []
    for index in fit_indices:
        sample = dataset[index]
        if sample['alpha'] is None:
            raise ValueError('Mask-surface initialization requires foreground alpha in every fit image')
        mask = (sample['alpha'][..., 0].numpy() > .9).astype(np.uint8)
        if padding:
            mask = cv2.dilate(mask, np.ones((2*padding+1, 2*padding+1), np.uint8))
        cameras.append((sample['viewmat'].double().numpy(), sample['K'].double().numpy(), mask.astype(bool)))
    coarse, coarse_origin, coarse_spacing = carve_mask_consensus(cameras, center, radius, 64, consensus)
    selected = np.argwhere(coarse)
    low = coarse_origin+selected.min(0)*coarse_spacing
    high = coarse_origin+selected.max(0)*coarse_spacing
    fine_center = (low+high)*.5
    fine_radius = float((high-low).max()*.5+2*coarse_spacing)
    occupied, origin, spacing = carve_mask_consensus(cameras, fine_center, fine_radius, grid_size, consensus)
    if surface_mode == 'occupancy':
        seeds = sample_occupancy_surface(occupied, origin, spacing, count, seed)
        field_record = {}
    elif surface_mode == 'distance':
        distance = (distance_transform_edt(~occupied)-distance_transform_edt(occupied))*spacing
        field = gaussian_filter(distance, sigma=.75, mode='nearest')
        seeds = sample_zero_surface(field, origin, spacing, count, seed)
        field_record = {'field': torch.from_numpy(field).float(),
                        'field_origin': torch.from_numpy(origin).float(), 'field_spacing': spacing}
    else:
        raise ValueError('surface_mode must be occupancy or distance')
    return {**seeds, 'scene': str(dataset.scene_path.resolve()), 'resolution': dataset.resolution,
            'fit_indices': list(fit_indices), 'val_indices': list(val_indices),
            'camera_bound_center': torch.from_numpy(center).float(), 'camera_bound_radius': radius,
            **field_record, 'seed': seed,
            'construction': {'coarse_side': 64, 'fine_side': grid_size, 'mask_padding_pixels': padding,
                             'consensus': consensus, 'alpha_threshold': .9, 'near_plane': .01,
                             'surface_mode': surface_mode, 'smoothing_sigma_voxels': .75,
                             'coarse_occupied': int(coarse.sum()),
                             'fine_occupied': int(occupied.sum()), 'fit_image_count': len(cameras),
                             'bound_frame_indices': bound_indices,
                             'scope': 'Fit-mask geometric initialization only, not true geometry or relighting recovery'}}


@torch.no_grad()
def initialize_mask_surfels(gaussians, record, dataset, fit_indices, val_indices):
    """Copy only geometry; opacity and all material/light states remain fresh."""
    if (record['scene'] != str(dataset.scene_path.resolve()) or record['resolution'] != dataset.resolution or
            record['fit_indices'] != fit_indices or record['val_indices'] != val_indices or
            record['frames'] != {i:dataset.frames[i] for i in fit_indices}):
        raise ValueError('Surfel initialization scene/resolution/full fit-validation lineage mismatch')
    if len(record['positions']) != len(gaussians.params['means']):
        raise ValueError('Surfel initialization point count must equal --points')
    torch.testing.assert_close(record['camera_bound_center'], gaussians.center.cpu(), rtol=1e-5, atol=1e-6)
    if not math.isclose(record['camera_bound_radius'], gaussians.radius, rel_tol=1e-5, abs_tol=1e-6):
        raise ValueError('Surfel initialization camera bounds mismatch')
    for target, value in (('means', record['positions']), ('quats', record['quats']), ('scales', record['scales'].log())):
        if value.shape != gaussians.params[target].shape or not torch.isfinite(value).all():
            raise ValueError(f'Invalid surfel initialization tensor: {target}')
        gaussians.params[target].copy_(value)
