"""Measure the existing GS3/SSD-GS render entrypoint without writing into a model."""

import argparse
import copy
import json
import runpy
import statistics
import sys
import time
from pathlib import Path

import numpy as np
import torch


ROOT = Path(__file__).resolve().parent.parent


@torch.no_grad()
def timed_modes(render_frame, frame_count, repeats=3):
    records = []
    for mode in ('fixed_light', 'changing_light'):
        for index in range(min(5, frame_count)):
            image = render_frame(index, mode)
            assert torch.isfinite(image).all(), (mode, index)
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        durations = []
        for _ in range(repeats):
            for index in range(frame_count):
                torch.cuda.synchronize()
                started = time.perf_counter()
                image = render_frame(index, mode)
                torch.cuda.synchronize()
                durations.append(time.perf_counter() - started)
                assert torch.isfinite(image).all(), (mode, index)
        records.append(dict(mode=mode, frames=frame_count, repeats=repeats,
                            milliseconds=1000 * statistics.mean(durations),
                            median_milliseconds=1000 * statistics.median(durations),
                            p95_milliseconds=1000 * float(np.percentile(durations, 95)),
                            fps=1 / statistics.mean(durations),
                            peak_allocated_MiB=torch.cuda.max_memory_allocated() / 2**20,
                            peak_reserved_MiB=torch.cuda.max_memory_reserved() / 2**20))
    return records


def baseline_profile(method, model_path, iteration, output, frame_count):
    project = ROOT / method
    sys.path.insert(0, str(project))
    namespace = runpy.run_path(str(project / 'render.py'), run_name='render_measurement')
    parser = argparse.ArgumentParser()
    model = namespace['ModelParams'](parser, sentinel=True)
    pipeline = namespace['PipelineParams'](parser)
    sys.argv = ['render_measurement', '-m', str(model_path)]
    args = namespace['get_combined_args'](parser)
    dataset = model.extract(args)
    dataset.eval = True
    dataset.data_device = 'cpu'
    dataset.view_num = 0
    dataset.use_nerual_phasefunc = True
    gamma = '/Synthetic_GS3/' in dataset.source_path

    @torch.no_grad()
    def measure(model_path, name, iteration, views, gaussians, pipeline, background, gamma):
        indices = np.linspace(0, len(views) - 1, frame_count, dtype=int).tolist()
        selected = [views[index] for index in indices]
        local_axes = gaussians.get_local_axis
        scales = gaussians.asg_func.get_asg_lam_miu
        axes = gaussians.asg_func.get_asg_axis
        light_stream, calc_stream = torch.cuda.Stream(), torch.cuda.Stream()
        if method == 'SSD-GS':
            sigmas = gaussians.asg_func.get_asg_sigma

        def frame(index, mode):
            view = copy.copy(selected[index])
            if mode == 'fixed_light':
                view.pl_pos = selected[0].pl_pos
            arguments = (view, gaussians, light_stream, calc_stream, local_axes, scales)
            if method == 'SSD-GS':
                arguments += (sigmas,)
            result = namespace['render'](*arguments, axes, pipeline, background)
            image = (result['render'] * result['shadow'] + result['other_effects']
                     if method == 'GS3' else result['render'])
            return image.pow(1 / 2.2) if gamma else image

        modes = timed_modes(frame, len(selected))
        model_files = [Path(model_path) / f'chkpnt{iteration}.pth',
                       Path(model_path) / f'point_cloud/iteration_{iteration}/point_cloud.ply']
        report = dict(method=method, model_path=str(model_path), iteration=iteration,
                      frame_indices=indices, modes=modes, gpu=torch.cuda.get_device_name(),
                      torch_version=torch.__version__, cuda_version=torch.version.cuda,
                      gaussians=len(gaussians.get_xyz),
                      image_size=[selected[0].image_height, selected[0].image_width],
                      checkpoint_MiB=sum(path.stat().st_size for path in model_files) / 2**20,
                      checkpoint_contents='Original loader-required checkpoint and PLY, including any training state; not a stripped deployment export.',
                      protocol='Original test cameras, renderer+RGB composition+observation transform; '
                               'synchronized wall time; excludes loading/metrics/disk IO; '
                               'no added light-pass caching; fixed_light uses the first selected light.')
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2) + '\n')

    # Reuse upstream model restoration exactly; replace only its image-writing callback.
    namespace['render_sets'].__globals__['render_set'] = measure
    namespace['render_sets'](dataset, iteration, pipeline.extract(args), True, False, False, gamma, False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--method', choices=['GS3', 'SSD-GS'], required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--iteration', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--frames', type=int, default=32)
    options = parser.parse_args()
    baseline_profile(options.method, options.model, options.iteration, options.output, options.frames)
